# Create the complete project structure and implementation files

import os
import json

# Define the project structure
project_structure = {
    "nba-analytics-backend": {
        "src": {
            "config": ["database.js", "jwt.js", "environment.js"],
            "controllers": ["authController.js", "donationController.js", "testimonialController.js"],
            "middleware": ["auth.js", "rateLimiter.js", "validation.js", "security.js"],
            "models": ["User.js", "Donation.js", "Testimonial.js"],
            "routes": ["authRoutes.js", "donationRoutes.js", "testimonialRoutes.js", "index.js"],
            "services": ["authService.js", "donationService.js", "testimonialService.js"],
            "utils": ["logger.js", "responseHandler.js", "errorHandler.js"]
        },
        "": [
            "app.js",
            "server.js", 
            "package.json",
            "docker-compose.yml",
            "Dockerfile",
            ".env.example",
            ".gitignore",
            "README.md"
        ]
    }
}

def print_structure(structure, level=0):
    for key, value in structure.items():
        indent = "  " * level
        if key == "":  # Root files
            for file in value:
                print(f"{indent}{file}")
        else:  # Directories
            print(f"{indent}{key}/")
            if isinstance(value, dict):
                print_structure(value, level + 1)
            elif isinstance(value, list):
                for file in value:
                    print(f"{indent}  {file}")

print("NBA Analytics Dashboard Backend - Project Structure:")
print("=" * 60)
print_structure(project_structure)