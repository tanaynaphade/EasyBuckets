# Create MongoDB models

# src/models/User.js
user_model = """const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const config = require('../config/environment');

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Name is required'],
        trim: true,
        minlength: [2, 'Name must be at least 2 characters'],
        maxlength: [50, 'Name must not exceed 50 characters']
    },
    email: {
        type: String,
        required: [true, 'Email is required'],
        unique: true,
        lowercase: true,
        trim: true,
        match: [/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/, 'Please provide a valid email']
    },
    password: {
        type: String,
        required: [true, 'Password is required'],
        minlength: [8, 'Password must be at least 8 characters'],
        select: false // Don't include password in queries by default
    },
    role: {
        type: String,
        enum: ['user', 'admin', 'moderator'],
        default: 'user'
    },
    isActive: {
        type: Boolean,
        default: true
    },
    isVerified: {
        type: Boolean,
        default: false
    },
    refreshTokens: [{
        token: String,
        createdAt: {
            type: Date,
            default: Date.now,
            expires: 604800 // 7 days
        }
    }],
    lastLogin: {
        type: Date
    },
    loginAttempts: {
        type: Number,
        default: 0
    },
    lockUntil: Date,
    passwordChangedAt: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true,
    toJSON: { 
        virtuals: true,
        transform: function(doc, ret) {
            delete ret.password;
            delete ret.refreshTokens;
            delete ret.__v;
            return ret;
        }
    },
    toObject: { virtuals: true }
});

// Indexes
userSchema.index({ email: 1 });
userSchema.index({ isActive: 1 });
userSchema.index({ createdAt: -1 });

// Virtual for account lock status
userSchema.virtual('isLocked').get(function() {
    return !!(this.lockUntil && this.lockUntil > Date.now());
});

// Pre-save middleware to hash password
userSchema.pre('save', async function(next) {
    // Only hash if password is modified
    if (!this.isModified('password')) return next();

    try {
        // Hash password
        this.password = await bcrypt.hash(this.password, config.SECURITY.BCRYPT_ROUNDS);
        this.passwordChangedAt = new Date();
        next();
    } catch (error) {
        next(error);
    }
});

// Instance method to compare password
userSchema.methods.comparePassword = async function(candidatePassword) {
    try {
        return await bcrypt.compare(candidatePassword, this.password);
    } catch (error) {
        throw error;
    }
};

// Instance method to increment login attempts
userSchema.methods.incLoginAttempts = function() {
    // If we have a previous lock that has expired, restart at 1
    if (this.lockUntil && this.lockUntil < Date.now()) {
        return this.updateOne({
            $unset: { lockUntil: 1 },
            $set: { loginAttempts: 1 }
        });
    }
    
    const updates = { $inc: { loginAttempts: 1 } };
    
    // Lock account after 5 failed attempts for 2 hours
    if (this.loginAttempts + 1 >= 5 && !this.isLocked) {
        updates.$set = { lockUntil: Date.now() + 2 * 60 * 60 * 1000 }; // 2 hours
    }
    
    return this.updateOne(updates);
};

// Instance method to reset login attempts
userSchema.methods.resetLoginAttempts = function() {
    return this.updateOne({
        $unset: { loginAttempts: 1, lockUntil: 1 }
    });
};

// Instance method to add refresh token
userSchema.methods.addRefreshToken = function(token) {
    this.refreshTokens.push({ token });
    return this.save();
};

// Instance method to remove refresh token
userSchema.methods.removeRefreshToken = function(token) {
    this.refreshTokens = this.refreshTokens.filter(rt => rt.token !== token);
    return this.save();
};

// Static method to find by email
userSchema.statics.findByEmail = function(email) {
    return this.findOne({ email: email.toLowerCase() });
};

// Static method to find active users
userSchema.statics.findActiveUsers = function() {
    return this.find({ isActive: true });
};

module.exports = mongoose.model('User', userSchema);
"""

# src/models/Donation.js  
donation_model = """const mongoose = require('mongoose');

const donationSchema = new mongoose.Schema({
    donorName: {
        type: String,
        required: [true, 'Donor name is required'],
        trim: true,
        minlength: [2, 'Donor name must be at least 2 characters'],
        maxlength: [100, 'Donor name must not exceed 100 characters']
    },
    donorEmail: {
        type: String,
        required: [true, 'Donor email is required'],
        lowercase: true,
        trim: true,
        match: [/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/, 'Please provide a valid email']
    },
    amount: {
        type: Number,
        required: [true, 'Donation amount is required'],
        min: [1, 'Minimum donation amount is $1'],
        max: [10000, 'Maximum donation amount is $10,000'],
        validate: {
            validator: function(v) {
                return Number.isFinite(v) && v > 0;
            },
            message: 'Amount must be a positive number'
        }
    },
    currency: {
        type: String,
        required: true,
        enum: ['USD', 'EUR', 'GBP', 'CAD'],
        default: 'USD'
    },
    message: {
        type: String,
        trim: true,
        maxlength: [500, 'Message must not exceed 500 characters']
    },
    isAnonymous: {
        type: Boolean,
        default: false
    },
    transactionId: {
        type: String,
        unique: true,
        sparse: true // Allow null values but ensure uniqueness when present
    },
    status: {
        type: String,
        enum: ['pending', 'completed', 'failed', 'refunded'],
        default: 'pending'
    },
    paymentMethod: {
        type: String,
        enum: ['credit_card', 'paypal', 'bank_transfer', 'crypto'],
        required: true
    },
    metadata: {
        ipAddress: String,
        userAgent: String,
        referrer: String,
        utmSource: String,
        utmMedium: String,
        utmCampaign: String
    },
    processedAt: Date,
    refundedAt: Date
}, {
    timestamps: true,
    toJSON: { 
        virtuals: true,
        transform: function(doc, ret) {
            // Hide sensitive information for anonymous donations
            if (ret.isAnonymous) {
                ret.donorName = 'Anonymous';
                delete ret.donorEmail;
            }
            delete ret.__v;
            return ret;
        }
    },
    toObject: { virtuals: true }
});

// Indexes
donationSchema.index({ donorEmail: 1 });
donationSchema.index({ amount: -1 });
donationSchema.index({ status: 1 });
donationSchema.index({ createdAt: -1 });
donationSchema.index({ transactionId: 1 }, { sparse: true });

// Virtual for formatted amount
donationSchema.virtual('formattedAmount').get(function() {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: this.currency
    }).format(this.amount);
});

// Pre-save middleware
donationSchema.pre('save', function(next) {
    // Generate transaction ID if not provided
    if (!this.transactionId && this.status === 'completed') {
        this.transactionId = `TXN_${Date.now()}_${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    }
    
    // Set processedAt timestamp when status changes to completed
    if (this.isModified('status') && this.status === 'completed' && !this.processedAt) {
        this.processedAt = new Date();
    }
    
    next();
});

// Static method to get leaderboard
donationSchema.statics.getLeaderboard = async function(limit = 10) {
    return this.aggregate([
        { $match: { status: 'completed', isAnonymous: false } },
        {
            $group: {
                _id: '$donorEmail',
                donorName: { $first: '$donorName' },
                totalAmount: { $sum: '$amount' },
                donationCount: { $sum: 1 },
                lastDonation: { $max: '$createdAt' }
            }
        },
        { $sort: { totalAmount: -1 } },
        { $limit: limit },
        {
            $project: {
                _id: 0,
                donorEmail: '$_id',
                donorName: 1,
                totalAmount: 1,
                donationCount: 1,
                lastDonation: 1,
                formattedTotal: {
                    $concat: ['$', { $toString: '$totalAmount' }]
                }
            }
        }
    ]);
};

// Static method to get donation statistics
donationSchema.statics.getStats = async function() {
    const stats = await this.aggregate([
        { $match: { status: 'completed' } },
        {
            $group: {
                _id: null,
                totalAmount: { $sum: '$amount' },
                totalDonations: { $sum: 1 },
                averageAmount: { $avg: '$amount' },
                maxAmount: { $max: '$amount' },
                minAmount: { $min: '$amount' }
            }
        }
    ]);
    
    return stats[0] || {
        totalAmount: 0,
        totalDonations: 0,
        averageAmount: 0,
        maxAmount: 0,
        minAmount: 0
    };
};

// Static method to get donations by date range
donationSchema.statics.getByDateRange = function(startDate, endDate, status = 'completed') {
    return this.find({
        status,
        createdAt: {
            $gte: new Date(startDate),
            $lte: new Date(endDate)
        }
    }).sort({ createdAt: -1 });
};

module.exports = mongoose.model('Donation', donationSchema);
"""

# src/models/Testimonial.js
testimonial_model = """const mongoose = require('mongoose');

const testimonialSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Name is required'],
        trim: true,
        minlength: [2, 'Name must be at least 2 characters'],
        maxlength: [100, 'Name must not exceed 100 characters']
    },
    email: {
        type: String,
        lowercase: true,
        trim: true,
        match: [/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/, 'Please provide a valid email'],
        select: false // Don't include email in queries by default for privacy
    },
    rating: {
        type: Number,
        required: [true, 'Rating is required'],
        min: [1, 'Rating must be between 1 and 5'],
        max: [5, 'Rating must be between 1 and 5'],
        validate: {
            validator: function(v) {
                return Number.isInteger(v) && v >= 1 && v <= 5;
            },
            message: 'Rating must be an integer between 1 and 5'
        }
    },
    review: {
        type: String,
        required: [true, 'Review text is required'],
        trim: true,
        minlength: [10, 'Review must be at least 10 characters'],
        maxlength: [1000, 'Review must not exceed 1000 characters']
    },
    isApproved: {
        type: Boolean,
        default: false
    },
    isFeatured: {
        type: Boolean,
        default: false
    },
    isVisible: {
        type: Boolean,
        default: true
    },
    metadata: {
        ipAddress: String,
        userAgent: String,
        source: {
            type: String,
            enum: ['website', 'mobile_app', 'api'],
            default: 'website'
        },
        language: {
            type: String,
            default: 'en'
        }
    },
    moderationNotes: {
        type: String,
        maxlength: [500, 'Moderation notes must not exceed 500 characters'],
        select: false
    },
    approvedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        select: false
    },
    approvedAt: {
        type: Date,
        select: false
    },
    rejectedAt: {
        type: Date,
        select: false
    }
}, {
    timestamps: true,
    toJSON: { 
        virtuals: true,
        transform: function(doc, ret) {
            delete ret.__v;
            delete ret.email; // Always hide email in JSON output
            delete ret.metadata;
            delete ret.moderationNotes;
            delete ret.approvedBy;
            delete ret.approvedAt;
            delete ret.rejectedAt;
            return ret;
        }
    },
    toObject: { virtuals: true }
});

// Indexes
testimonialSchema.index({ rating: -1 });
testimonialSchema.index({ isApproved: 1, isVisible: 1 });
testimonialSchema.index({ isFeatured: 1 });
testimonialSchema.index({ createdAt: -1 });

// Virtual for star display
testimonialSchema.virtual('stars').get(function() {
    return '★'.repeat(this.rating) + '☆'.repeat(5 - this.rating);
});

// Virtual for review preview (first 100 characters)
testimonialSchema.virtual('reviewPreview').get(function() {
    if (this.review.length <= 100) {
        return this.review;
    }
    return this.review.substring(0, 100) + '...';
});

// Pre-save middleware
testimonialSchema.pre('save', function(next) {
    // Auto-approve high ratings from verified sources (optional business logic)
    if (this.isNew && this.rating >= 4 && !this.isApproved) {
        // You could add additional checks here
    }
    
    // Set approval timestamp
    if (this.isModified('isApproved') && this.isApproved && !this.approvedAt) {
        this.approvedAt = new Date();
    }
    
    next();
});

// Static method to get approved testimonials
testimonialSchema.statics.getApproved = function(limit = 10) {
    return this.find({ 
        isApproved: true, 
        isVisible: true 
    })
    .sort({ createdAt: -1 })
    .limit(limit);
};

// Static method to get featured testimonials
testimonialSchema.statics.getFeatured = function() {
    return this.find({ 
        isApproved: true, 
        isVisible: true,
        isFeatured: true 
    }).sort({ createdAt: -1 });
};

// Static method to get testimonials by rating
testimonialSchema.statics.getByRating = function(rating) {
    return this.find({ 
        rating,
        isApproved: true,
        isVisible: true 
    }).sort({ createdAt: -1 });
};

// Static method to get rating statistics
testimonialSchema.statics.getRatingStats = async function() {
    const stats = await this.aggregate([
        { 
            $match: { 
                isApproved: true, 
                isVisible: true 
            } 
        },
        {
            $group: {
                _id: null,
                totalReviews: { $sum: 1 },
                averageRating: { $avg: '$rating' },
                ratingDistribution: {
                    $push: '$rating'
                }
            }
        },
        {
            $project: {
                _id: 0,
                totalReviews: 1,
                averageRating: { $round: ['$averageRating', 2] },
                ratingCounts: {
                    '5': {
                        $size: {
                            $filter: {
                                input: '$ratingDistribution',
                                cond: { $eq: ['$$this', 5] }
                            }
                        }
                    },
                    '4': {
                        $size: {
                            $filter: {
                                input: '$ratingDistribution',
                                cond: { $eq: ['$$this', 4] }
                            }
                        }
                    },
                    '3': {
                        $size: {
                            $filter: {
                                input: '$ratingDistribution',
                                cond: { $eq: ['$$this', 3] }
                            }
                        }
                    },
                    '2': {
                        $size: {
                            $filter: {
                                input: '$ratingDistribution',
                                cond: { $eq: ['$$this', 2] }
                            }
                        }
                    },
                    '1': {
                        $size: {
                            $filter: {
                                input: '$ratingDistribution',
                                cond: { $eq: ['$$this', 1] }
                            }
                        }
                    }
                }
            }
        }
    ]);
    
    return stats[0] || {
        totalReviews: 0,
        averageRating: 0,
        ratingCounts: { '5': 0, '4': 0, '3': 0, '2': 0, '1': 0 }
    };
};

// Static method to get pending testimonials for moderation
testimonialSchema.statics.getPendingModeration = function() {
    return this.find({ isApproved: false })
           .select('+email +moderationNotes +approvedBy')
           .sort({ createdAt: 1 });
};

module.exports = mongoose.model('Testimonial', testimonialSchema);
"""

# Save model files
with open('User.js', 'w') as f:
    f.write(user_model)

with open('Donation.js', 'w') as f:
    f.write(donation_model)

with open('Testimonial.js', 'w') as f:
    f.write(testimonial_model)

print("✅ Created MongoDB models:")
print("  - src/models/User.js")
print("  - src/models/Donation.js") 
print("  - src/models/Testimonial.js")