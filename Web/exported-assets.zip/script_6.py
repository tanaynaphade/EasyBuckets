# Create service files

# src/services/authService.js
auth_service = """const bcrypt = require('bcrypt');
const User = require('../models/User');
const jwtManager = require('../config/jwt');
const config = require('../config/environment');
const { AppError, AuthError, ValidationError, ConflictError } = require('../utils/errorHandler');
const logger = require('../utils/logger');

class AuthService {
    /**
     * Register a new user
     * @param {Object} userData - User registration data
     * @returns {Object} User data and tokens
     */
    static async register(userData) {
        try {
            const { name, email, password } = userData;

            // Check if user already exists
            const existingUser = await User.findByEmail(email);
            if (existingUser) {
                throw new ConflictError('Email is already registered');
            }

            // Create new user
            const user = new User({
                name: name.trim(),
                email: email.toLowerCase().trim(),
                password
            });

            await user.save();

            // Generate tokens
            const tokens = jwtManager.generateTokenPair(user);

            // Store refresh token
            await user.addRefreshToken(tokens.refreshToken);

            // Remove password from response
            const userResponse = user.toJSON();

            logger.logUserAction(user._id, 'REGISTER', { email });

            return {
                user: userResponse,
                tokens
            };
        } catch (error) {
            if (error.code === 11000) {
                throw new ConflictError('Email is already registered');
            }
            throw error;
        }
    }

    /**
     * Login user
     * @param {String} email - User email
     * @param {String} password - User password
     * @param {String} ipAddress - User IP address
     * @returns {Object} User data and tokens
     */
    static async login(email, password, ipAddress) {
        try {
            // Find user with password field
            const user = await User.findOne({ email: email.toLowerCase() })
                .select('+password +loginAttempts +lockUntil +refreshTokens');

            if (!user) {
                throw new AuthError('Invalid email or password');
            }

            // Check if account is locked
            if (user.isLocked) {
                logger.logSecurityEvent('LOGIN_ATTEMPT_LOCKED_ACCOUNT', { 
                    email, 
                    ipAddress,
                    lockUntil: user.lockUntil
                });
                throw new AuthError('Account is temporarily locked. Please try again later');
            }

            // Check if account is active
            if (!user.isActive) {
                throw new AuthError('Account is deactivated');
            }

            // Verify password
            const isPasswordValid = await user.comparePassword(password);
            if (!isPasswordValid) {
                // Increment login attempts
                await user.incLoginAttempts();
                
                logger.logSecurityEvent('FAILED_LOGIN_ATTEMPT', { 
                    email, 
                    ipAddress,
                    attempts: user.loginAttempts + 1
                });
                
                throw new AuthError('Invalid email or password');
            }

            // Reset login attempts on successful login
            if (user.loginAttempts && user.loginAttempts > 0) {
                await user.resetLoginAttempts();
            }

            // Update last login
            user.lastLogin = new Date();
            await user.save();

            // Generate tokens
            const tokens = jwtManager.generateTokenPair(user);

            // Store refresh token
            await user.addRefreshToken(tokens.refreshToken);

            // Remove sensitive fields from response
            const userResponse = user.toJSON();

            logger.logUserAction(user._id, 'LOGIN', { email, ipAddress });

            return {
                user: userResponse,
                tokens
            };
        } catch (error) {
            throw error;
        }
    }

    /**
     * Refresh access token
     * @param {String} refreshToken - Refresh token
     * @returns {Object} New tokens
     */
    static async refreshToken(refreshToken) {
        try {
            // Verify refresh token
            const decoded = jwtManager.verifyRefreshToken(refreshToken);

            // Find user and validate refresh token
            const user = await User.findById(decoded.id).select('+refreshTokens');
            if (!user) {
                throw new AuthError('User not found');
            }

            const storedToken = user.refreshTokens.find(rt => rt.token === refreshToken);
            if (!storedToken) {
                throw new AuthError('Invalid refresh token');
            }

            // Generate new tokens
            const tokens = jwtManager.generateTokenPair(user);

            // Replace old refresh token with new one
            await user.removeRefreshToken(refreshToken);
            await user.addRefreshToken(tokens.refreshToken);

            logger.logUserAction(user._id, 'TOKEN_REFRESH');

            return { tokens };
        } catch (error) {
            throw error;
        }
    }

    /**
     * Logout user
     * @param {String} userId - User ID
     * @param {String} refreshToken - Refresh token to remove
     */
    static async logout(userId, refreshToken = null) {
        try {
            const user = await User.findById(userId).select('+refreshTokens');
            if (!user) {
                throw new AuthError('User not found');
            }

            if (refreshToken) {
                // Remove specific refresh token
                await user.removeRefreshToken(refreshToken);
            } else {
                // Remove all refresh tokens (logout from all devices)
                user.refreshTokens = [];
                await user.save();
            }

            logger.logUserAction(userId, 'LOGOUT');
        } catch (error) {
            throw error;
        }
    }

    /**
     * Change user password
     * @param {String} userId - User ID
     * @param {String} currentPassword - Current password
     * @param {String} newPassword - New password
     */
    static async changePassword(userId, currentPassword, newPassword) {
        try {
            const user = await User.findById(userId).select('+password');
            if (!user) {
                throw new AuthError('User not found');
            }

            // Verify current password
            const isCurrentPasswordValid = await user.comparePassword(currentPassword);
            if (!isCurrentPasswordValid) {
                throw new AuthError('Current password is incorrect');
            }

            // Check if new password is different
            const isSamePassword = await user.comparePassword(newPassword);
            if (isSamePassword) {
                throw new ValidationError('New password must be different from current password');
            }

            // Update password
            user.password = newPassword;
            user.passwordChangedAt = new Date();
            
            // Clear all refresh tokens (force re-login on all devices)
            user.refreshTokens = [];
            
            await user.save();

            logger.logUserAction(userId, 'PASSWORD_CHANGE');

            return { message: 'Password changed successfully' };
        } catch (error) {
            throw error;
        }
    }

    /**
     * Get user profile
     * @param {String} userId - User ID
     * @returns {Object} User profile
     */
    static async getProfile(userId) {
        try {
            const user = await User.findById(userId);
            if (!user) {
                throw new AuthError('User not found');
            }

            return user.toJSON();
        } catch (error) {
            throw error;
        }
    }

    /**
     * Update user profile
     * @param {String} userId - User ID
     * @param {Object} updateData - Profile update data
     * @returns {Object} Updated user profile
     */
    static async updateProfile(userId, updateData) {
        try {
            const allowedUpdates = ['name'];
            const updates = {};

            // Filter allowed updates
            for (const key of allowedUpdates) {
                if (updateData[key] !== undefined) {
                    updates[key] = updateData[key];
                }
            }

            if (Object.keys(updates).length === 0) {
                throw new ValidationError('No valid fields to update');
            }

            const user = await User.findByIdAndUpdate(
                userId,
                updates,
                { new: true, runValidators: true }
            );

            if (!user) {
                throw new AuthError('User not found');
            }

            logger.logUserAction(userId, 'PROFILE_UPDATE', { updates: Object.keys(updates) });

            return user.toJSON();
        } catch (error) {
            throw error;
        }
    }

    /**
     * Deactivate user account
     * @param {String} userId - User ID
     */
    static async deactivateAccount(userId) {
        try {
            const user = await User.findByIdAndUpdate(
                userId,
                { 
                    isActive: false,
                    refreshTokens: [] // Clear all sessions
                },
                { new: true }
            );

            if (!user) {
                throw new AuthError('User not found');
            }

            logger.logUserAction(userId, 'ACCOUNT_DEACTIVATION');

            return { message: 'Account deactivated successfully' };
        } catch (error) {
            throw error;
        }
    }

    /**
     * Get user login history/stats
     * @param {String} userId - User ID
     * @returns {Object} User stats
     */
    static async getUserStats(userId) {
        try {
            const user = await User.findById(userId);
            if (!user) {
                throw new AuthError('User not found');
            }

            return {
                lastLogin: user.lastLogin,
                accountCreated: user.createdAt,
                isVerified: user.isVerified,
                role: user.role,
                loginAttempts: user.loginAttempts || 0,
                isLocked: user.isLocked
            };
        } catch (error) {
            throw error;
        }
    }
}

module.exports = AuthService;
"""

# src/services/donationService.js
donation_service = """const Donation = require('../models/Donation');
const { AppError, NotFoundError, ValidationError } = require('../utils/errorHandler');
const logger = require('../utils/logger');

class DonationService {
    /**
     * Create a new donation
     * @param {Object} donationData - Donation data
     * @param {Object} metadata - Request metadata (IP, User-Agent, etc.)
     * @returns {Object} Created donation
     */
    static async createDonation(donationData, metadata = {}) {
        try {
            const donation = new Donation({
                ...donationData,
                metadata: {
                    ipAddress: metadata.ip,
                    userAgent: metadata.userAgent,
                    referrer: metadata.referrer,
                    source: metadata.source || 'website'
                }
            });

            await donation.save();

            logger.info('New donation created', {
                donationId: donation._id,
                amount: donation.amount,
                donorEmail: donation.isAnonymous ? '[ANONYMOUS]' : donation.donorEmail,
                paymentMethod: donation.paymentMethod
            });

            return donation.toJSON();
        } catch (error) {
            logger.error('Error creating donation:', error);
            throw error;
        }
    }

    /**
     * Get donation by ID
     * @param {String} donationId - Donation ID
     * @returns {Object} Donation data
     */
    static async getDonationById(donationId) {
        try {
            const donation = await Donation.findById(donationId);
            
            if (!donation) {
                throw new NotFoundError('Donation not found');
            }

            return donation.toJSON();
        } catch (error) {
            throw error;
        }
    }

    /**
     * Get donations with pagination and filtering
     * @param {Object} options - Query options
     * @returns {Object} Donations and pagination info
     */
    static async getDonations(options = {}) {
        try {
            const {
                page = 1,
                limit = 10,
                status,
                paymentMethod,
                minAmount,
                maxAmount,
                startDate,
                endDate,
                sort = '-createdAt'
            } = options;

            // Build query
            const query = {};

            if (status) query.status = status;
            if (paymentMethod) query.paymentMethod = paymentMethod;
            
            if (minAmount || maxAmount) {
                query.amount = {};
                if (minAmount) query.amount.$gte = parseFloat(minAmount);
                if (maxAmount) query.amount.$lte = parseFloat(maxAmount);
            }

            if (startDate || endDate) {
                query.createdAt = {};
                if (startDate) query.createdAt.$gte = new Date(startDate);
                if (endDate) query.createdAt.$lte = new Date(endDate);
            }

            // Calculate pagination
            const skip = (page - 1) * limit;
            const total = await Donation.countDocuments(query);

            // Fetch donations
            const donations = await Donation.find(query)
                .sort(sort)
                .skip(skip)
                .limit(parseInt(limit));

            return {
                donations: donations.map(donation => donation.toJSON()),
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total,
                    totalPages: Math.ceil(total / limit),
                    hasNext: page * limit < total,
                    hasPrev: page > 1
                }
            };
        } catch (error) {
            throw error;
        }
    }

    /**
     * Get donation leaderboard
     * @param {Number} limit - Number of top donors to return
     * @returns {Array} Leaderboard data
     */
    static async getLeaderboard(limit = 10) {
        try {
            const leaderboard = await Donation.getLeaderboard(limit);
            
            logger.info('Leaderboard generated', { 
                topDonors: leaderboard.length,
                limit 
            });

            return leaderboard;
        } catch (error) {
            logger.error('Error generating leaderboard:', error);
            throw error;
        }
    }

    /**
     * Get donation statistics
     * @param {Object} filters - Date range and other filters
     * @returns {Object} Donation statistics
     */
    static async getDonationStats(filters = {}) {
        try {
            const { startDate, endDate } = filters;
            
            // Get basic stats
            const basicStats = await Donation.getStats();

            // Get stats for date range if provided
            let periodStats = null;
            if (startDate || endDate) {
                const query = { status: 'completed' };
                
                if (startDate || endDate) {
                    query.createdAt = {};
                    if (startDate) query.createdAt.$gte = new Date(startDate);
                    if (endDate) query.createdAt.$lte = new Date(endDate);
                }

                const periodData = await Donation.aggregate([
                    { $match: query },
                    {
                        $group: {
                            _id: null,
                            totalAmount: { $sum: '$amount' },
                            totalDonations: { $sum: 1 },
                            averageAmount: { $avg: '$amount' },
                            maxAmount: { $max: '$amount' },
                            minAmount: { $min: '$amount' }
                        }
                    }
                ]);

                periodStats = periodData[0] || {
                    totalAmount: 0,
                    totalDonations: 0,
                    averageAmount: 0,
                    maxAmount: 0,
                    minAmount: 0
                };
            }

            // Get donation trends (monthly breakdown)
            const trends = await Donation.aggregate([
                { $match: { status: 'completed' } },
                {
                    $group: {
                        _id: {
                            year: { $year: '$createdAt' },
                            month: { $month: '$createdAt' }
                        },
                        totalAmount: { $sum: '$amount' },
                        totalDonations: { $sum: 1 },
                        averageAmount: { $avg: '$amount' }
                    }
                },
                { $sort: { '_id.year': -1, '_id.month': -1 } },
                { $limit: 12 } // Last 12 months
            ]);

            // Payment method distribution
            const paymentMethodStats = await Donation.aggregate([
                { $match: { status: 'completed' } },
                {
                    $group: {
                        _id: '$paymentMethod',
                        count: { $sum: 1 },
                        totalAmount: { $sum: '$amount' }
                    }
                },
                { $sort: { totalAmount: -1 } }
            ]);

            return {
                overall: basicStats,
                ...(periodStats && { period: periodStats }),
                trends: trends.map(trend => ({
                    year: trend._id.year,
                    month: trend._id.month,
                    totalAmount: trend.totalAmount,
                    totalDonations: trend.totalDonations,
                    averageAmount: Math.round(trend.averageAmount * 100) / 100
                })),
                paymentMethods: paymentMethodStats.map(pm => ({
                    method: pm._id,
                    count: pm.count,
                    totalAmount: pm.totalAmount,
                    percentage: Math.round((pm.totalAmount / basicStats.totalAmount) * 100 * 100) / 100
                }))
            };
        } catch (error) {
            logger.error('Error generating donation stats:', error);
            throw error;
        }
    }

    /**
     * Update donation status (for payment processing)
     * @param {String} donationId - Donation ID
     * @param {String} status - New status
     * @param {String} transactionId - Transaction ID from payment processor
     * @returns {Object} Updated donation
     */
    static async updateDonationStatus(donationId, status, transactionId = null) {
        try {
            const updateData = { status };
            
            if (transactionId) {
                updateData.transactionId = transactionId;
            }

            if (status === 'completed') {
                updateData.processedAt = new Date();
            } else if (status === 'refunded') {
                updateData.refundedAt = new Date();
            }

            const donation = await Donation.findByIdAndUpdate(
                donationId,
                updateData,
                { new: true, runValidators: true }
            );

            if (!donation) {
                throw new NotFoundError('Donation not found');
            }

            logger.info('Donation status updated', {
                donationId,
                oldStatus: 'pending',
                newStatus: status,
                transactionId
            });

            return donation.toJSON();
        } catch (error) {
            logger.error('Error updating donation status:', error);
            throw error;
        }
    }

    /**
     * Get donations by donor email
     * @param {String} email - Donor email
     * @param {Object} options - Query options
     * @returns {Object} Donations and pagination info
     */
    static async getDonationsByEmail(email, options = {}) {
        try {
            const { page = 1, limit = 10 } = options;
            
            const query = { 
                donorEmail: email.toLowerCase(),
                status: 'completed'
            };

            const skip = (page - 1) * limit;
            const total = await Donation.countDocuments(query);

            const donations = await Donation.find(query)
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(parseInt(limit));

            // Calculate donor stats
            const donorStats = await Donation.aggregate([
                { $match: query },
                {
                    $group: {
                        _id: null,
                        totalAmount: { $sum: '$amount' },
                        totalDonations: { $sum: 1 },
                        firstDonation: { $min: '$createdAt' },
                        lastDonation: { $max: '$createdAt' }
                    }
                }
            ]);

            return {
                donations: donations.map(donation => donation.toJSON()),
                donorStats: donorStats[0] || {
                    totalAmount: 0,
                    totalDonations: 0,
                    firstDonation: null,
                    lastDonation: null
                },
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total,
                    totalPages: Math.ceil(total / limit),
                    hasNext: page * limit < total,
                    hasPrev: page > 1
                }
            };
        } catch (error) {
            throw error;
        }
    }

    /**
     * Delete donation (admin only, for testing/cleanup)
     * @param {String} donationId - Donation ID
     */
    static async deleteDonation(donationId) {
        try {
            const donation = await Donation.findByIdAndDelete(donationId);
            
            if (!donation) {
                throw new NotFoundError('Donation not found');
            }

            logger.warn('Donation deleted', {
                donationId,
                amount: donation.amount,
                donorEmail: donation.donorEmail
            });

            return { message: 'Donation deleted successfully' };
        } catch (error) {
            throw error;
        }
    }
}

module.exports = DonationService;
"""

# src/services/testimonialService.js
testimonial_service = """const Testimonial = require('../models/Testimonial');
const { AppError, NotFoundError, ValidationError } = require('../utils/errorHandler');
const logger = require('../utils/logger');

class TestimonialService {
    /**
     * Create a new testimonial
     * @param {Object} testimonialData - Testimonial data
     * @param {Object} metadata - Request metadata
     * @returns {Object} Created testimonial
     */
    static async createTestimonial(testimonialData, metadata = {}) {
        try {
            const testimonial = new Testimonial({
                ...testimonialData,
                metadata: {
                    ipAddress: metadata.ip,
                    userAgent: metadata.userAgent,
                    source: metadata.source || 'website',
                    language: metadata.language || 'en'
                }
            });

            await testimonial.save();

            logger.info('New testimonial submitted', {
                testimonialId: testimonial._id,
                name: testimonial.name,
                rating: testimonial.rating,
                reviewLength: testimonial.review.length
            });

            return testimonial.toJSON();
        } catch (error) {
            logger.error('Error creating testimonial:', error);
            throw error;
        }
    }

    /**
     * Get testimonial by ID
     * @param {String} testimonialId - Testimonial ID
     * @param {Boolean} includePrivate - Include private fields (admin only)
     * @returns {Object} Testimonial data
     */
    static async getTestimonialById(testimonialId, includePrivate = false) {
        try {
            let query = Testimonial.findById(testimonialId);
            
            if (includePrivate) {
                query = query.select('+email +moderationNotes +approvedBy +approvedAt +rejectedAt');
            }

            const testimonial = await query;
            
            if (!testimonial) {
                throw new NotFoundError('Testimonial not found');
            }

            return testimonial.toJSON();
        } catch (error) {
            throw error;
        }
    }

    /**
     * Get testimonials with pagination and filtering
     * @param {Object} options - Query options
     * @returns {Object} Testimonials and pagination info
     */
    static async getTestimonials(options = {}) {
        try {
            const {
                page = 1,
                limit = 10,
                rating,
                isApproved,
                isFeatured,
                isVisible,
                sort = '-createdAt',
                includePrivate = false
            } = options;

            // Build query
            const query = {};

            if (rating) query.rating = parseInt(rating);
            if (isApproved !== undefined) query.isApproved = isApproved === 'true';
            if (isFeatured !== undefined) query.isFeatured = isFeatured === 'true';
            if (isVisible !== undefined) query.isVisible = isVisible === 'true';

            // For public access, only show approved and visible testimonials
            if (!includePrivate) {
                query.isApproved = true;
                query.isVisible = true;
            }

            // Calculate pagination
            const skip = (page - 1) * limit;
            const total = await Testimonial.countDocuments(query);

            // Build query with optional private fields
            let testimonialQuery = Testimonial.find(query);
            
            if (includePrivate) {
                testimonialQuery = testimonialQuery.select('+email +moderationNotes +approvedBy');
            }

            const testimonials = await testimonialQuery
                .sort(sort)
                .skip(skip)
                .limit(parseInt(limit));

            return {
                testimonials: testimonials.map(testimonial => testimonial.toJSON()),
                pagination: {
                    page: parseInt(page),
                    limit: parseInt(limit),
                    total,
                    totalPages: Math.ceil(total / limit),
                    hasNext: page * limit < total,
                    hasPrev: page > 1
                }
            };
        } catch (error) {
            throw error;
        }
    }

    /**
     * Get approved testimonials for public display
     * @param {Number} limit - Number of testimonials to return
     * @returns {Array} Approved testimonials
     */
    static async getApprovedTestimonials(limit = 10) {
        try {
            const testimonials = await Testimonial.getApproved(limit);
            return testimonials.map(testimonial => testimonial.toJSON());
        } catch (error) {
            throw error;
        }
    }

    /**
     * Get featured testimonials
     * @returns {Array} Featured testimonials
     */
    static async getFeaturedTestimonials() {
        try {
            const testimonials = await Testimonial.getFeatured();
            return testimonials.map(testimonial => testimonial.toJSON());
        } catch (error) {
            throw error;
        }
    }

    /**
     * Get testimonials by rating
     * @param {Number} rating - Star rating (1-5)
     * @returns {Array} Testimonials with specified rating
     */
    static async getTestimonialsByRating(rating) {
        try {
            if (rating < 1 || rating > 5) {
                throw new ValidationError('Rating must be between 1 and 5');
            }

            const testimonials = await Testimonial.getByRating(rating);
            return testimonials.map(testimonial => testimonial.toJSON());
        } catch (error) {
            throw error;
        }
    }

    /**
     * Get rating statistics
     * @returns {Object} Rating statistics
     */
    static async getRatingStats() {
        try {
            const stats = await Testimonial.getRatingStats();
            
            logger.info('Rating statistics generated', {
                totalReviews: stats.totalReviews,
                averageRating: stats.averageRating
            });

            return stats;
        } catch (error) {
            logger.error('Error generating rating stats:', error);
            throw error;
        }
    }

    /**
     * Approve testimonial (admin/moderator only)
     * @param {String} testimonialId - Testimonial ID
     * @param {String} moderatorId - ID of the moderator approving
     * @param {String} notes - Optional moderation notes
     * @returns {Object} Updated testimonial
     */
    static async approveTestimonial(testimonialId, moderatorId, notes = '') {
        try {
            const testimonial = await Testimonial.findByIdAndUpdate(
                testimonialId,
                {
                    isApproved: true,
                    approvedBy: moderatorId,
                    approvedAt: new Date(),
                    ...(notes && { moderationNotes: notes })
                },
                { new: true, runValidators: true }
            ).select('+moderationNotes +approvedBy +approvedAt');

            if (!testimonial) {
                throw new NotFoundError('Testimonial not found');
            }

            logger.info('Testimonial approved', {
                testimonialId,
                moderatorId,
                rating: testimonial.rating
            });

            return testimonial.toJSON();
        } catch (error) {
            logger.error('Error approving testimonial:', error);
            throw error;
        }
    }

    /**
     * Reject testimonial (admin/moderator only)
     * @param {String} testimonialId - Testimonial ID
     * @param {String} moderatorId - ID of the moderator rejecting
     * @param {String} reason - Reason for rejection
     * @returns {Object} Updated testimonial
     */
    static async rejectTestimonial(testimonialId, moderatorId, reason) {
        try {
            const testimonial = await Testimonial.findByIdAndUpdate(
                testimonialId,
                {
                    isApproved: false,
                    isVisible: false,
                    rejectedAt: new Date(),
                    moderationNotes: reason
                },
                { new: true, runValidators: true }
            ).select('+moderationNotes +rejectedAt');

            if (!testimonial) {
                throw new NotFoundError('Testimonial not found');
            }

            logger.warn('Testimonial rejected', {
                testimonialId,
                moderatorId,
                reason
            });

            return testimonial.toJSON();
        } catch (error) {
            logger.error('Error rejecting testimonial:', error);
            throw error;
        }
    }

    /**
     * Feature testimonial (admin only)
     * @param {String} testimonialId - Testimonial ID
     * @param {Boolean} featured - Whether to feature or unfeature
     * @returns {Object} Updated testimonial
     */
    static async featureTestimonial(testimonialId, featured = true) {
        try {
            const testimonial = await Testimonial.findByIdAndUpdate(
                testimonialId,
                { isFeatured: featured },
                { new: true, runValidators: true }
            );

            if (!testimonial) {
                throw new NotFoundError('Testimonial not found');
            }

            // Only approved testimonials can be featured
            if (featured && !testimonial.isApproved) {
                throw new ValidationError('Only approved testimonials can be featured');
            }

            logger.info(`Testimonial ${featured ? 'featured' : 'unfeatured'}`, {
                testimonialId,
                rating: testimonial.rating
            });

            return testimonial.toJSON();
        } catch (error) {
            throw error;
        }
    }

    /**
     * Get pending testimonials for moderation
     * @returns {Array} Pending testimonials
     */
    static async getPendingTestimonials() {
        try {
            const testimonials = await Testimonial.getPendingModeration();
            
            logger.info('Pending testimonials retrieved', {
                count: testimonials.length
            });

            return testimonials.map(testimonial => testimonial.toJSON());
        } catch (error) {
            throw error;
        }
    }

    /**
     * Hide/show testimonial (admin only)
     * @param {String} testimonialId - Testimonial ID
     * @param {Boolean} visible - Whether testimonial should be visible
     * @returns {Object} Updated testimonial
     */
    static async toggleVisibility(testimonialId, visible = true) {
        try {
            const testimonial = await Testimonial.findByIdAndUpdate(
                testimonialId,
                { isVisible: visible },
                { new: true, runValidators: true }
            );

            if (!testimonial) {
                throw new NotFoundError('Testimonial not found');
            }

            logger.info(`Testimonial ${visible ? 'shown' : 'hidden'}`, {
                testimonialId
            });

            return testimonial.toJSON();
        } catch (error) {
            throw error;
        }
    }

    /**
     * Delete testimonial (admin only)
     * @param {String} testimonialId - Testimonial ID
     */
    static async deleteTestimonial(testimonialId) {
        try {
            const testimonial = await Testimonial.findByIdAndDelete(testimonialId);
            
            if (!testimonial) {
                throw new NotFoundError('Testimonial not found');
            }

            logger.warn('Testimonial deleted', {
                testimonialId,
                name: testimonial.name,
                rating: testimonial.rating
            });

            return { message: 'Testimonial deleted successfully' };
        } catch (error) {
            throw error;
        }
    }

    /**
     * Get testimonial analytics
     * @param {Object} filters - Date range and other filters
     * @returns {Object} Testimonial analytics
     */
    static async getTestimonialAnalytics(filters = {}) {
        try {
            const { startDate, endDate } = filters;
            
            // Build date query
            const dateQuery = {};
            if (startDate || endDate) {
                dateQuery.createdAt = {};
                if (startDate) dateQuery.createdAt.$gte = new Date(startDate);
                if (endDate) dateQuery.createdAt.$lte = new Date(endDate);
            }

            // Get basic statistics
            const totalTestimonials = await Testimonial.countDocuments(dateQuery);
            const approvedTestimonials = await Testimonial.countDocuments({
                ...dateQuery,
                isApproved: true
            });
            const pendingTestimonials = await Testimonial.countDocuments({
                ...dateQuery,
                isApproved: false
            });

            // Get rating distribution
            const ratingStats = await Testimonial.getRatingStats();

            // Get testimonials over time (monthly)
            const timeSeriesData = await Testimonial.aggregate([
                { $match: dateQuery },
                {
                    $group: {
                        _id: {
                            year: { $year: '$createdAt' },
                            month: { $month: '$createdAt' }
                        },
                        count: { $sum: 1 },
                        averageRating: { $avg: '$rating' },
                        approved: {
                            $sum: { $cond: ['$isApproved', 1, 0] }
                        }
                    }
                },
                { $sort: { '_id.year': -1, '_id.month': -1 } },
                { $limit: 12 }
            ]);

            // Get approval rate
            const approvalRate = totalTestimonials > 0 
                ? Math.round((approvedTestimonials / totalTestimonials) * 100 * 100) / 100
                : 0;

            return {
                summary: {
                    totalTestimonials,
                    approvedTestimonials,
                    pendingTestimonials,
                    approvalRate
                },
                ratings: ratingStats,
                timeSeries: timeSeriesData.map(item => ({
                    year: item._id.year,
                    month: item._id.month,
                    count: item.count,
                    averageRating: Math.round(item.averageRating * 100) / 100,
                    approved: item.approved,
                    approvalRate: Math.round((item.approved / item.count) * 100 * 100) / 100
                }))
            };
        } catch (error) {
            logger.error('Error generating testimonial analytics:', error);
            throw error;
        }
    }
}

module.exports = TestimonialService;
"""

# Save service files
with open('authService.js', 'w') as f:
    f.write(auth_service)

with open('donationService.js', 'w') as f:
    f.write(donation_service)

with open('testimonialService.js', 'w') as f:
    f.write(testimonial_service)

print("✅ Created service files:")
print("  - src/services/authService.js")
print("  - src/services/donationService.js") 
print("  - src/services/testimonialService.js")