# Create the main application files

# package.json
package_json = {
    "name": "nba-analytics-backend",
    "version": "1.0.0",
    "description": "NBA Analytics Dashboard Backend - MongoDB based backend with JWT authentication",
    "main": "server.js",
    "scripts": {
        "start": "node server.js",
        "dev": "nodemon server.js",
        "test": "jest",
        "docker:build": "docker build -t nba-analytics-backend .",
        "docker:run": "docker-compose up -d",
        "docker:stop": "docker-compose down",
        "seed": "node scripts/seedData.js"
    },
    "keywords": ["nba", "analytics", "mongodb", "express", "jwt", "docker"],
    "author": "Your Name",
    "license": "MIT",
    "dependencies": {
        "express": "^4.18.2",
        "mongoose": "^7.5.0",
        "bcrypt": "^5.1.1",
        "jsonwebtoken": "^9.0.2",
        "express-validator": "^7.0.1",
        "express-rate-limit": "^6.10.0",
        "helmet": "^7.0.0",
        "cors": "^2.8.5",
        "dotenv": "^16.3.1",
        "winston": "^3.10.0",
        "compression": "^1.7.4",
        "morgan": "^1.10.0"
    },
    "devDependencies": {
        "nodemon": "^3.0.1",
        "jest": "^29.6.2",
        "supertest": "^6.3.3"
    },
    "engines": {
        "node": ">=18.0.0"
    }
}

# .env.example
env_example = """# MongoDB Configuration
MONGODB_URI=mongodb://mongo:27017/nba_analytics
MONGODB_USER=nba_user
MONGODB_PASSWORD=secure_password_123

# JWT Configuration  
JWT_SECRET=your-super-secure-jwt-secret-key-min-32-chars
JWT_EXPIRES_IN=24h
JWT_REFRESH_SECRET=your-refresh-token-secret-key

# Server Configuration
PORT=5000
NODE_ENV=development

# Security Configuration
BCRYPT_ROUNDS=12
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# CORS Configuration
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:3001

# Logging
LOG_LEVEL=info
"""

# .gitignore
gitignore = """.env
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*
.npm
.node_repl_history
*.tgz
*.tar.gz
.DS_Store
logs/
coverage/
.nyc_output/
dist/
build/
.vscode/
.idea/
"""

# docker-compose.yml
docker_compose = """version: '3.8'

services:
  app:
    build: 
      context: .
      dockerfile: Dockerfile
    container_name: nba-analytics-backend
    restart: unless-stopped
    ports:
      - "${PORT:-5000}:5000"
    environment:
      - NODE_ENV=production
      - PORT=5000
      - MONGODB_URI=mongodb://mongo:27017/nba_analytics
      - MONGODB_USER=${MONGODB_USER}
      - MONGODB_PASSWORD=${MONGODB_PASSWORD}
      - JWT_SECRET=${JWT_SECRET}
      - JWT_EXPIRES_IN=${JWT_EXPIRES_IN}
      - BCRYPT_ROUNDS=${BCRYPT_ROUNDS}
    depends_on:
      - mongo
    networks:
      - nba-network
    volumes:
      - ./logs:/app/logs

  mongo:
    image: mongo:7.0
    container_name: nba-analytics-mongodb  
    restart: unless-stopped
    ports:
      - "27017:27017"
    environment:
      MONGO_INITDB_ROOT_USERNAME: ${MONGODB_USER}
      MONGO_INITDB_ROOT_PASSWORD: ${MONGODB_PASSWORD}
      MONGO_INITDB_DATABASE: nba_analytics
    volumes:
      - mongodb_data:/data/db
      - mongodb_config:/data/configdb
      - ./mongo-init:/docker-entrypoint-initdb.d
    networks:
      - nba-network

volumes:
  mongodb_data:
    driver: local
  mongodb_config:
    driver: local

networks:
  nba-network:
    driver: bridge
"""

# Dockerfile
dockerfile = """FROM node:18-alpine

WORKDIR /app

# Install dependencies
COPY package*.json ./
RUN npm ci --only=production

# Copy source code
COPY . .

# Create logs directory
RUN mkdir -p logs

# Create non-root user
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nodejs -u 1001
RUN chown -R nodejs:nodejs /app
USER nodejs

# Expose port
EXPOSE 5000

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD node healthcheck.js

CMD ["npm", "start"]
"""

# Save all files
with open('package.json', 'w') as f:
    json.dump(package_json, f, indent=2)

with open('.env.example', 'w') as f:
    f.write(env_example)

with open('.gitignore', 'w') as f:
    f.write(gitignore)

with open('docker-compose.yml', 'w') as f:
    f.write(docker_compose)

with open('Dockerfile', 'w') as f:
    f.write(dockerfile)

print("✅ Created core configuration files:")
print("  - package.json")
print("  - .env.example") 
print("  - .gitignore")
print("  - docker-compose.yml")
print("  - Dockerfile")