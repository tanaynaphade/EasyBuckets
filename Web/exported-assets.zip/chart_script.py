import plotly.graph_objects as go
import plotly.express as px
import json
import numpy as np

# Load the data
data = {
  "nodes": [
    {"id": "api", "label": "NBA Analytics Backend API", "type": "main", "level": 0},
    {"id": "auth", "label": "Authentication & Users", "type": "feature", "level": 1},
    {"id": "donations", "label": "Donations & Leaderboard", "type": "feature", "level": 1},
    {"id": "testimonials", "label": "Testimonials & Reviews", "type": "feature", "level": 1},
    {"id": "mongodb", "label": "MongoDB Database", "type": "infrastructure", "level": 2},
    {"id": "docker", "label": "Docker Containers", "type": "infrastructure", "level": 2},
    {"id": "security", "label": "Security Middleware", "type": "security", "level": 2},
    {"id": "logging", "label": "Logging & Monitoring", "type": "infrastructure", "level": 2},
    {"id": "nodejs", "label": "Node.js + Express", "type": "tech", "level": 3},
    {"id": "jwt", "label": "JWT Authentication", "type": "security", "level": 3},
    {"id": "ratelimit", "label": "Rate Limiting", "type": "security", "level": 3},
    {"id": "validation", "label": "Input Validation", "type": "security", "level": 3},
    {"id": "errorhandling", "label": "Error Handling", "type": "tech", "level": 3}
  ],
  "edges": [
    {"source": "api", "target": "auth"},
    {"source": "api", "target": "donations"},
    {"source": "api", "target": "testimonials"},
    {"source": "auth", "target": "mongodb"},
    {"source": "donations", "target": "mongodb"},
    {"source": "testimonials", "target": "mongodb"},
    {"source": "api", "target": "docker"},
    {"source": "api", "target": "security"},
    {"source": "api", "target": "logging"},
    {"source": "security", "target": "jwt"},
    {"source": "security", "target": "ratelimit"},
    {"source": "security", "target": "validation"},
    {"source": "api", "target": "nodejs"},
    {"source": "nodejs", "target": "errorhandling"}
  ]
}

# Updated color mapping with more distinct colors
color_map = {
    'main': '#1FB8CD',      # Strong cyan
    'feature': '#DB4545',   # Bright red  
    'infrastructure': '#2E8B57',  # Sea green
    'security': '#D2BA4C',  # Moderate yellow (swapped with tech)
    'tech': '#5D878F'       # Cyan (swapped with security)
}

# Create well-spaced node positions
node_positions = {}

# Level 0: Main API (center top)
node_positions['api'] = (0, 4)

# Level 1: Features (spread horizontally with more space)
features = ['auth', 'donations', 'testimonials']
for i, node_id in enumerate(features):
    x = (i - 1) * 2.5  # Increased spacing
    node_positions[node_id] = (x, 2.5)

# Level 2: Infrastructure and Security (well-spaced)
level2_positions = {
    'mongodb': (0, 1),        # Center under features
    'docker': (-3.5, 1),      # Far left
    'security': (2.5, 1),     # Right
    'logging': (3.5, 1)       # Far right
}
for node_id, pos in level2_positions.items():
    node_positions[node_id] = pos

# Level 3: Tech stack (better aligned and spaced)
level3_positions = {
    'nodejs': (-3.5, -0.5),    # Under docker
    'errorhandling': (-3.5, -2), # Under nodejs
    'jwt': (1.5, -0.5),        # Under security (left)
    'ratelimit': (2.5, -0.5),  # Under security (center)
    'validation': (3.5, -0.5)  # Under security (right)
}
for node_id, pos in level3_positions.items():
    node_positions[node_id] = pos

# Create figure
fig = go.Figure()

# Add edges with better routing to avoid label overlap
for edge in data['edges']:
    source_pos = node_positions[edge['source']]
    target_pos = node_positions[edge['target']]
    
    fig.add_trace(go.Scatter(
        x=[source_pos[0], target_pos[0]],
        y=[source_pos[1], target_pos[1]],
        mode='lines',
        line=dict(color='rgba(70,70,70,0.6)', width=2.5),
        showlegend=False,
        hoverinfo='skip'
    ))

# Add nodes with text positioned outside to avoid overlap
for node_type in ['main', 'feature', 'infrastructure', 'security', 'tech']:
    nodes_of_type = [node for node in data['nodes'] if node['type'] == node_type]
    if nodes_of_type:
        x_coords = [node_positions[node['id']][0] for node in nodes_of_type]
        y_coords = [node_positions[node['id']][1] for node in nodes_of_type]
        labels = [node['label'] for node in nodes_of_type]
        
        # Truncate labels to 15 characters as per instructions
        display_labels = []
        for label in labels:
            if len(label) > 15:
                # Smart truncation - try to keep meaningful parts
                if '&' in label:
                    parts = label.split('&')
                    display_labels.append(parts[0].strip()[:15])
                else:
                    display_labels.append(label[:15])
            else:
                display_labels.append(label)
        
        # Different marker sizes for hierarchy
        marker_size = 35 if node_type == 'main' else 30
        
        # Add markers without text first
        fig.add_trace(go.Scatter(
            x=x_coords,
            y=y_coords,
            mode='markers',
            marker=dict(
                size=marker_size,
                color=color_map[node_type],
                line=dict(width=2, color='white')
            ),
            name=node_type.title(),
            showlegend=True,
            hovertemplate='<b>%{text}</b><br>Type: ' + node_type + '<extra></extra>',
            text=display_labels
        ))
        
        # Add text labels positioned above markers to avoid overlap
        fig.add_trace(go.Scatter(
            x=x_coords,
            y=[y + 0.3 for y in y_coords],  # Position text above markers
            mode='text',
            text=display_labels,
            textfont=dict(size=10, color='black', family='Arial'),
            showlegend=False,
            hoverinfo='skip'
        ))

# Update layout with expanded range to accommodate spacing
fig.update_layout(
    title="NBA Analytics Backend Architecture",
    showlegend=True,
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    xaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[-5, 5]),
    yaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[-2.5, 5]),
    plot_bgcolor='rgba(0,0,0,0)',
    paper_bgcolor='rgba(0,0,0,0)'
)

# Update traces to clip on axis
fig.update_traces(cliponaxis=False)

# Save as both PNG and SVG
fig.write_image("nba_architecture.png")
fig.write_image("nba_architecture.svg", format="svg")

fig.show()