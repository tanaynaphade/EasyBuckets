# Create configuration files

# src/config/environment.js
environment_config = """const dotenv = require('dotenv');
const path = require('path');

// Load environment variables
dotenv.config();

// Validate required environment variables
const requiredEnvVars = [
    'MONGODB_URI',
    'JWT_SECRET',
    'PORT'
];

const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);
if (missingVars.length > 0) {
    throw new Error(`Missing required environment variables: ${missingVars.join(', ')}`);
}

const config = {
    // Server Configuration
    PORT: parseInt(process.env.PORT, 10) || 5000,
    NODE_ENV: process.env.NODE_ENV || 'development',
    
    // MongoDB Configuration
    MONGODB: {
        URI: process.env.MONGODB_URI,
        USER: process.env.MONGODB_USER,
        PASSWORD: process.env.MONGODB_PASSWORD,
        OPTIONS: {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            maxPoolSize: 10,
            serverSelectionTimeoutMS: 5000,
            socketTimeoutMS: 45000,
            bufferMaxEntries: 0
        }
    },
    
    // JWT Configuration
    JWT: {
        SECRET: process.env.JWT_SECRET,
        EXPIRES_IN: process.env.JWT_EXPIRES_IN || '24h',
        REFRESH_SECRET: process.env.JWT_REFRESH_SECRET || process.env.JWT_SECRET + '_refresh',
        REFRESH_EXPIRES_IN: process.env.JWT_REFRESH_EXPIRES_IN || '7d'
    },
    
    // Security Configuration
    SECURITY: {
        BCRYPT_ROUNDS: parseInt(process.env.BCRYPT_ROUNDS, 10) || 12,
        RATE_LIMIT_WINDOW_MS: parseInt(process.env.RATE_LIMIT_WINDOW_MS, 10) || 15 * 60 * 1000, // 15 minutes
        RATE_LIMIT_MAX_REQUESTS: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS, 10) || 100,
        ALLOWED_ORIGINS: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : ['http://localhost:3000']
    },
    
    // Logging Configuration
    LOGGING: {
        LEVEL: process.env.LOG_LEVEL || 'info',
        FILE_PATH: path.join(process.cwd(), 'logs')
    }
};

// Validation functions
config.isProduction = () => config.NODE_ENV === 'production';
config.isDevelopment = () => config.NODE_ENV === 'development';
config.isTest = () => config.NODE_ENV === 'test';

module.exports = config;
"""

# src/config/database.js  
database_config = """const mongoose = require('mongoose');
const config = require('./environment');
const logger = require('../utils/logger');

class Database {
    constructor() {
        this.isConnected = false;
        this.connection = null;
    }

    async connect() {
        try {
            if (this.isConnected) {
                logger.warn('Database already connected');
                return this.connection;
            }

            const options = {
                ...config.MONGODB.OPTIONS,
                // Add authentication if credentials are provided
                ...(config.MONGODB.USER && config.MONGODB.PASSWORD && {
                    auth: {
                        username: config.MONGODB.USER,
                        password: config.MONGODB.PASSWORD
                    },
                    authSource: 'admin'
                })
            };

            this.connection = await mongoose.connect(config.MONGODB.URI, options);
            this.isConnected = true;

            logger.info('✅ MongoDB connected successfully');
            
            // Handle connection events
            this.setupEventListeners();
            
            return this.connection;
        } catch (error) {
            logger.error('❌ MongoDB connection error:', error);
            throw error;
        }
    }

    setupEventListeners() {
        mongoose.connection.on('connected', () => {
            logger.info('📡 Mongoose connected to MongoDB');
        });

        mongoose.connection.on('error', (err) => {
            logger.error('🚨 Mongoose connection error:', err);
        });

        mongoose.connection.on('disconnected', () => {
            logger.warn('⚠️  Mongoose disconnected from MongoDB');
            this.isConnected = false;
        });

        // Handle application termination
        process.on('SIGINT', async () => {
            await this.disconnect();
            process.exit(0);
        });
    }

    async disconnect() {
        try {
            if (this.isConnected) {
                await mongoose.connection.close();
                this.isConnected = false;
                logger.info('🔌 MongoDB connection closed');
            }
        } catch (error) {
            logger.error('❌ Error closing MongoDB connection:', error);
            throw error;
        }
    }

    getConnectionStatus() {
        return {
            isConnected: this.isConnected,
            readyState: mongoose.connection.readyState,
            host: mongoose.connection.host,
            port: mongoose.connection.port,
            name: mongoose.connection.name
        };
    }
}

module.exports = new Database();
"""

# src/config/jwt.js
jwt_config = """const jwt = require('jsonwebtoken');
const config = require('./environment');
const logger = require('../utils/logger');

class JWTManager {
    constructor() {
        this.secret = config.JWT.SECRET;
        this.refreshSecret = config.JWT.REFRESH_SECRET;
        this.expiresIn = config.JWT.EXPIRES_IN;
        this.refreshExpiresIn = config.JWT.REFRESH_EXPIRES_IN;
    }

    /**
     * Generate access token
     * @param {Object} payload - Token payload
     * @returns {String} JWT token
     */
    generateAccessToken(payload) {
        try {
            const tokenPayload = {
                id: payload.id,
                email: payload.email,
                role: payload.role || 'user',
                iat: Math.floor(Date.now() / 1000)
            };

            return jwt.sign(tokenPayload, this.secret, {
                expiresIn: this.expiresIn,
                issuer: 'nba-analytics',
                audience: 'nba-analytics-users'
            });
        } catch (error) {
            logger.error('Error generating access token:', error);
            throw error;
        }
    }

    /**
     * Generate refresh token
     * @param {Object} payload - Token payload 
     * @returns {String} Refresh token
     */
    generateRefreshToken(payload) {
        try {
            return jwt.sign(
                { id: payload.id, tokenType: 'refresh' },
                this.refreshSecret,
                { 
                    expiresIn: this.refreshExpiresIn,
                    issuer: 'nba-analytics'
                }
            );
        } catch (error) {
            logger.error('Error generating refresh token:', error);
            throw error;
        }
    }

    /**
     * Generate both access and refresh tokens
     * @param {Object} user - User object
     * @returns {Object} Token pair
     */
    generateTokenPair(user) {
        const payload = {
            id: user._id.toString(),
            email: user.email,
            role: user.role
        };

        return {
            accessToken: this.generateAccessToken(payload),
            refreshToken: this.generateRefreshToken(payload),
            expiresIn: this.expiresIn
        };
    }

    /**
     * Verify access token
     * @param {String} token - JWT token
     * @returns {Object} Decoded payload
     */
    verifyAccessToken(token) {
        try {
            return jwt.verify(token, this.secret, {
                issuer: 'nba-analytics',
                audience: 'nba-analytics-users'
            });
        } catch (error) {
            logger.warn('Invalid access token:', error.message);
            throw error;
        }
    }

    /**
     * Verify refresh token
     * @param {String} token - Refresh token
     * @returns {Object} Decoded payload
     */
    verifyRefreshToken(token) {
        try {
            const decoded = jwt.verify(token, this.refreshSecret, {
                issuer: 'nba-analytics'
            });
            
            if (decoded.tokenType !== 'refresh') {
                throw new Error('Invalid token type');
            }
            
            return decoded;
        } catch (error) {
            logger.warn('Invalid refresh token:', error.message);
            throw error;
        }
    }

    /**
     * Extract token from Authorization header
     * @param {String} authHeader - Authorization header value
     * @returns {String} Token
     */
    extractToken(authHeader) {
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            throw new Error('Invalid authorization header format');
        }
        return authHeader.substring(7);
    }

    /**
     * Decode token without verification (for debugging)
     * @param {String} token - JWT token
     * @returns {Object} Decoded payload
     */
    decodeToken(token) {
        return jwt.decode(token, { complete: true });
    }
}

module.exports = new JWTManager();
"""

# Save configuration files
with open('environment.js', 'w') as f:
    f.write(environment_config)

with open('database.js', 'w') as f:
    f.write(database_config)

with open('jwt.js', 'w') as f:
    f.write(jwt_config)

print("✅ Created configuration files:")
print("  - src/config/environment.js")
print("  - src/config/database.js") 
print("  - src/config/jwt.js")