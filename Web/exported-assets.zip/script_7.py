# Create controller files

# src/controllers/authController.js
auth_controller = """const AuthService = require('../services/authService');
const ResponseHandler = require('../utils/responseHandler');
const { asyncHandler } = require('../utils/errorHandler');
const logger = require('../utils/logger');

class AuthController {
    /**
     * Register a new user
     * POST /api/auth/register
     */
    static register = asyncHandler(async (req, res) => {
        const { name, email, password } = req.body;
        
        const result = await AuthService.register({ name, email, password });
        
        logger.logUserAction(result.user.id, 'REGISTER_SUCCESS', { 
            email: result.user.email 
        });
        
        ResponseHandler.created(res, result, 'User registered successfully');
    });

    /**
     * Login user
     * POST /api/auth/login
     */
    static login = asyncHandler(async (req, res) => {
        const { email, password } = req.body;
        const ipAddress = req.ip;
        
        const result = await AuthService.login(email, password, ipAddress);
        
        ResponseHandler.success(res, result, 'Login successful');
    });

    /**
     * Refresh access token
     * POST /api/auth/refresh
     */
    static refreshToken = asyncHandler(async (req, res) => {
        const { refreshToken } = req.body;
        
        const result = await AuthService.refreshToken(refreshToken);
        
        ResponseHandler.success(res, result, 'Token refreshed successfully');
    });

    /**
     * Logout user
     * POST /api/auth/logout
     */
    static logout = asyncHandler(async (req, res) => {
        const { refreshToken } = req.body;
        const userId = req.user.id;
        
        await AuthService.logout(userId, refreshToken);
        
        ResponseHandler.success(res, null, 'Logged out successfully');
    });

    /**
     * Logout from all devices
     * POST /api/auth/logout-all
     */
    static logoutAll = asyncHandler(async (req, res) => {
        const userId = req.user.id;
        
        await AuthService.logout(userId); // No refresh token = logout all
        
        ResponseHandler.success(res, null, 'Logged out from all devices');
    });

    /**
     * Get current user profile
     * GET /api/auth/profile
     */
    static getProfile = asyncHandler(async (req, res) => {
        const userId = req.user.id;
        
        const profile = await AuthService.getProfile(userId);
        
        ResponseHandler.success(res, profile, 'Profile retrieved successfully');
    });

    /**
     * Update user profile
     * PUT /api/auth/profile
     */
    static updateProfile = asyncHandler(async (req, res) => {
        const userId = req.user.id;
        const updateData = req.body;
        
        const updatedProfile = await AuthService.updateProfile(userId, updateData);
        
        logger.logUserAction(userId, 'PROFILE_UPDATE_SUCCESS');
        
        ResponseHandler.success(res, updatedProfile, 'Profile updated successfully');
    });

    /**
     * Change user password
     * POST /api/auth/change-password
     */
    static changePassword = asyncHandler(async (req, res) => {
        const userId = req.user.id;
        const { currentPassword, newPassword } = req.body;
        
        const result = await AuthService.changePassword(userId, currentPassword, newPassword);
        
        logger.logUserAction(userId, 'PASSWORD_CHANGE_SUCCESS');
        
        ResponseHandler.success(res, result, 'Password changed successfully');
    });

    /**
     * Deactivate user account
     * DELETE /api/auth/account
     */
    static deactivateAccount = asyncHandler(async (req, res) => {
        const userId = req.user.id;
        
        const result = await AuthService.deactivateAccount(userId);
        
        logger.logUserAction(userId, 'ACCOUNT_DEACTIVATION');
        
        ResponseHandler.success(res, result, 'Account deactivated successfully');
    });

    /**
     * Get user statistics
     * GET /api/auth/stats
     */
    static getUserStats = asyncHandler(async (req, res) => {
        const userId = req.user.id;
        
        const stats = await AuthService.getUserStats(userId);
        
        ResponseHandler.success(res, stats, 'User statistics retrieved');
    });

    /**
     * Verify token (for middleware testing)
     * GET /api/auth/verify
     */
    static verifyToken = asyncHandler(async (req, res) => {
        // If we reach here, token is valid (middleware passed)
        const user = req.user;
        
        ResponseHandler.success(res, {
            isValid: true,
            user: {
                id: user.id,
                email: user.email,
                role: user.role
            }
        }, 'Token is valid');
    });

    /**
     * Get current user session info
     * GET /api/auth/session
     */
    static getSessionInfo = asyncHandler(async (req, res) => {
        const user = req.user;
        
        const sessionInfo = {
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role
            },
            loginTime: user.lastLogin,
            sessionValid: true
        };
        
        ResponseHandler.success(res, sessionInfo, 'Session information retrieved');
    });
}

module.exports = AuthController;
"""

# src/controllers/donationController.js
donation_controller = """const DonationService = require('../services/donationService');
const ResponseHandler = require('../utils/responseHandler');
const { asyncHandler } = require('../utils/errorHandler');
const logger = require('../utils/logger');

class DonationController {
    /**
     * Create a new donation
     * POST /api/donations
     */
    static createDonation = asyncHandler(async (req, res) => {
        const donationData = req.body;
        
        // Add request metadata
        const metadata = {
            ip: req.ip,
            userAgent: req.get('User-Agent'),
            referrer: req.get('Referer'),
            source: 'website'
        };
        
        const donation = await DonationService.createDonation(donationData, metadata);
        
        logger.info('Donation submitted', {
            donationId: donation.id,
            amount: donation.amount,
            paymentMethod: donation.paymentMethod,
            ip: req.ip
        });
        
        ResponseHandler.created(res, donation, 'Donation submitted successfully');
    });

    /**
     * Get donation by ID
     * GET /api/donations/:id
     */
    static getDonationById = asyncHandler(async (req, res) => {
        const { id } = req.params;
        
        const donation = await DonationService.getDonationById(id);
        
        ResponseHandler.success(res, donation, 'Donation retrieved successfully');
    });

    /**
     * Get donations with pagination and filtering
     * GET /api/donations
     */
    static getDonations = asyncHandler(async (req, res) => {
        const options = {
            page: parseInt(req.query.page) || 1,
            limit: parseInt(req.query.limit) || 10,
            status: req.query.status,
            paymentMethod: req.query.paymentMethod,
            minAmount: req.query.minAmount,
            maxAmount: req.query.maxAmount,
            startDate: req.query.startDate,
            endDate: req.query.endDate,
            sort: req.query.sort || '-createdAt'
        };
        
        const result = await DonationService.getDonations(options);
        
        ResponseHandler.paginated(
            res,
            result.donations,
            result.pagination,
            'Donations retrieved successfully'
        );
    });

    /**
     * Get donation leaderboard
     * GET /api/donations/leaderboard
     */
    static getLeaderboard = asyncHandler(async (req, res) => {
        const limit = parseInt(req.query.limit) || 10;
        
        const leaderboard = await DonationService.getLeaderboard(limit);
        
        ResponseHandler.success(
            res, 
            { leaderboard }, 
            'Leaderboard retrieved successfully'
        );
    });

    /**
     * Get donation statistics
     * GET /api/donations/stats
     */
    static getDonationStats = asyncHandler(async (req, res) => {
        const filters = {
            startDate: req.query.startDate,
            endDate: req.query.endDate
        };
        
        const stats = await DonationService.getDonationStats(filters);
        
        ResponseHandler.success(res, stats, 'Donation statistics retrieved');
    });

    /**
     * Update donation status (admin/payment processor webhook)
     * PATCH /api/donations/:id/status
     */
    static updateDonationStatus = asyncHandler(async (req, res) => {
        const { id } = req.params;
        const { status, transactionId } = req.body;
        
        const donation = await DonationService.updateDonationStatus(id, status, transactionId);
        
        logger.info('Donation status updated', {
            donationId: id,
            status,
            transactionId,
            updatedBy: req.user?.id || 'system'
        });
        
        ResponseHandler.success(res, donation, 'Donation status updated successfully');
    });

    /**
     * Get donations by donor email
     * GET /api/donations/by-email/:email
     */
    static getDonationsByEmail = asyncHandler(async (req, res) => {
        const { email } = req.params;
        const options = {
            page: parseInt(req.query.page) || 1,
            limit: parseInt(req.query.limit) || 10
        };
        
        const result = await DonationService.getDonationsByEmail(email, options);
        
        ResponseHandler.paginated(
            res,
            result.donations,
            result.pagination,
            'Donor donations retrieved successfully',
            200,
            { donorStats: result.donorStats }
        );
    });

    /**
     * Delete donation (admin only, for cleanup)
     * DELETE /api/donations/:id
     */
    static deleteDonation = asyncHandler(async (req, res) => {
        const { id } = req.params;
        
        const result = await DonationService.deleteDonation(id);
        
        logger.warn('Donation deleted by admin', {
            donationId: id,
            deletedBy: req.user.id
        });
        
        ResponseHandler.success(res, result, 'Donation deleted successfully');
    });

    /**
     * Process donation webhook (for payment processors)
     * POST /api/donations/webhook
     */
    static processWebhook = asyncHandler(async (req, res) => {
        const webhookData = req.body;
        
        // This would typically validate webhook signature and process payment updates
        // For now, we'll just log the webhook data
        logger.info('Donation webhook received', {
            webhookData,
            ip: req.ip,
            userAgent: req.get('User-Agent')
        });
        
        // In a real implementation, you would:
        // 1. Verify webhook signature
        // 2. Extract donation ID and new status
        // 3. Update donation status
        // 4. Send confirmation emails
        
        ResponseHandler.success(res, { received: true }, 'Webhook processed successfully');
    });

    /**
     * Export donations to CSV (admin only)
     * GET /api/donations/export
     */
    static exportDonations = asyncHandler(async (req, res) => {
        const options = {
            status: req.query.status,
            startDate: req.query.startDate,
            endDate: req.query.endDate,
            paymentMethod: req.query.paymentMethod
        };
        
        // Get all donations matching criteria (no pagination for export)
        const result = await DonationService.getDonations({ 
            ...options, 
            limit: 10000 // Large limit for export
        });
        
        // Convert to CSV format
        const csvData = result.donations.map(donation => ({
            id: donation.id,
            donorName: donation.isAnonymous ? 'Anonymous' : donation.donorName,
            donorEmail: donation.isAnonymous ? 'N/A' : donation.donorEmail,
            amount: donation.amount,
            currency: donation.currency,
            paymentMethod: donation.paymentMethod,
            status: donation.status,
            transactionId: donation.transactionId || 'N/A',
            message: donation.message || 'N/A',
            createdAt: donation.createdAt,
            processedAt: donation.processedAt || 'N/A'
        }));
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=donations-export.csv');
        
        // Convert to CSV string (simple implementation)
        const csvString = [
            Object.keys(csvData[0]).join(','),
            ...csvData.map(row => Object.values(row).map(val => 
                typeof val === 'string' && val.includes(',') ? `"${val}"` : val
            ).join(','))
        ].join('\\n');
        
        logger.info('Donations exported', {
            count: csvData.length,
            exportedBy: req.user.id,
            filters: options
        });
        
        res.send(csvString);
    });
}

module.exports = DonationController;
"""

# src/controllers/testimonialController.js
testimonial_controller = """const TestimonialService = require('../services/testimonialService');
const ResponseHandler = require('../utils/responseHandler');
const { asyncHandler } = require('../utils/errorHandler');
const logger = require('../utils/logger');

class TestimonialController {
    /**
     * Create a new testimonial
     * POST /api/testimonials
     */
    static createTestimonial = asyncHandler(async (req, res) => {
        const testimonialData = req.body;
        
        // Add request metadata
        const metadata = {
            ip: req.ip,
            userAgent: req.get('User-Agent'),
            source: 'website',
            language: req.get('Accept-Language')?.substring(0, 2) || 'en'
        };
        
        const testimonial = await TestimonialService.createTestimonial(testimonialData, metadata);
        
        logger.info('Testimonial submitted', {
            testimonialId: testimonial.id,
            name: testimonial.name,
            rating: testimonial.rating,
            ip: req.ip
        });
        
        ResponseHandler.created(res, testimonial, 'Testimonial submitted successfully');
    });

    /**
     * Get testimonial by ID
     * GET /api/testimonials/:id
     */
    static getTestimonialById = asyncHandler(async (req, res) => {
        const { id } = req.params;
        const includePrivate = req.user?.role === 'admin' || req.user?.role === 'moderator';
        
        const testimonial = await TestimonialService.getTestimonialById(id, includePrivate);
        
        ResponseHandler.success(res, testimonial, 'Testimonial retrieved successfully');
    });

    /**
     * Get testimonials with pagination and filtering
     * GET /api/testimonials
     */
    static getTestimonials = asyncHandler(async (req, res) => {
        const includePrivate = req.user?.role === 'admin' || req.user?.role === 'moderator';
        
        const options = {
            page: parseInt(req.query.page) || 1,
            limit: parseInt(req.query.limit) || 10,
            rating: req.query.rating,
            isApproved: req.query.isApproved,
            isFeatured: req.query.isFeatured,
            isVisible: req.query.isVisible,
            sort: req.query.sort || '-createdAt',
            includePrivate
        };
        
        const result = await TestimonialService.getTestimonials(options);
        
        ResponseHandler.paginated(
            res,
            result.testimonials,
            result.pagination,
            'Testimonials retrieved successfully'
        );
    });

    /**
     * Get approved testimonials for public display
     * GET /api/testimonials/approved
     */
    static getApprovedTestimonials = asyncHandler(async (req, res) => {
        const limit = parseInt(req.query.limit) || 10;
        
        const testimonials = await TestimonialService.getApprovedTestimonials(limit);
        
        ResponseHandler.success(res, testimonials, 'Approved testimonials retrieved');
    });

    /**
     * Get featured testimonials
     * GET /api/testimonials/featured
     */
    static getFeaturedTestimonials = asyncHandler(async (req, res) => {
        const testimonials = await TestimonialService.getFeaturedTestimonials();
        
        ResponseHandler.success(res, testimonials, 'Featured testimonials retrieved');
    });

    /**
     * Get testimonials by rating
     * GET /api/testimonials/rating/:rating
     */
    static getTestimonialsByRating = asyncHandler(async (req, res) => {
        const { rating } = req.params;
        
        const testimonials = await TestimonialService.getTestimonialsByRating(parseInt(rating));
        
        ResponseHandler.success(
            res, 
            testimonials, 
            `${rating}-star testimonials retrieved`
        );
    });

    /**
     * Get rating statistics
     * GET /api/testimonials/stats/ratings
     */
    static getRatingStats = asyncHandler(async (req, res) => {
        const stats = await TestimonialService.getRatingStats();
        
        ResponseHandler.success(res, stats, 'Rating statistics retrieved');
    });

    /**
     * Approve testimonial (admin/moderator only)
     * PATCH /api/testimonials/:id/approve
     */
    static approveTestimonial = asyncHandler(async (req, res) => {
        const { id } = req.params;
        const { notes } = req.body;
        const moderatorId = req.user.id;
        
        const testimonial = await TestimonialService.approveTestimonial(id, moderatorId, notes);
        
        logger.info('Testimonial approved', {
            testimonialId: id,
            moderatorId,
            moderatorRole: req.user.role
        });
        
        ResponseHandler.success(res, testimonial, 'Testimonial approved successfully');
    });

    /**
     * Reject testimonial (admin/moderator only)
     * PATCH /api/testimonials/:id/reject
     */
    static rejectTestimonial = asyncHandler(async (req, res) => {
        const { id } = req.params;
        const { reason } = req.body;
        const moderatorId = req.user.id;
        
        const testimonial = await TestimonialService.rejectTestimonial(id, moderatorId, reason);
        
        logger.warn('Testimonial rejected', {
            testimonialId: id,
            moderatorId,
            reason
        });
        
        ResponseHandler.success(res, testimonial, 'Testimonial rejected');
    });

    /**
     * Feature/unfeature testimonial (admin only)
     * PATCH /api/testimonials/:id/feature
     */
    static featureTestimonial = asyncHandler(async (req, res) => {
        const { id } = req.params;
        const { featured = true } = req.body;
        
        const testimonial = await TestimonialService.featureTestimonial(id, featured);
        
        logger.info(`Testimonial ${featured ? 'featured' : 'unfeatured'}`, {
            testimonialId: id,
            adminId: req.user.id
        });
        
        ResponseHandler.success(
            res, 
            testimonial, 
            `Testimonial ${featured ? 'featured' : 'unfeatured'} successfully`
        );
    });

    /**
     * Get pending testimonials for moderation
     * GET /api/testimonials/pending
     */
    static getPendingTestimonials = asyncHandler(async (req, res) => {
        const testimonials = await TestimonialService.getPendingTestimonials();
        
        ResponseHandler.success(res, testimonials, 'Pending testimonials retrieved');
    });

    /**
     * Toggle testimonial visibility (admin only)
     * PATCH /api/testimonials/:id/visibility
     */
    static toggleVisibility = asyncHandler(async (req, res) => {
        const { id } = req.params;
        const { visible = true } = req.body;
        
        const testimonial = await TestimonialService.toggleVisibility(id, visible);
        
        logger.info(`Testimonial ${visible ? 'shown' : 'hidden'}`, {
            testimonialId: id,
            adminId: req.user.id
        });
        
        ResponseHandler.success(
            res, 
            testimonial, 
            `Testimonial ${visible ? 'shown' : 'hidden'} successfully`
        );
    });

    /**
     * Delete testimonial (admin only)
     * DELETE /api/testimonials/:id
     */
    static deleteTestimonial = asyncHandler(async (req, res) => {
        const { id } = req.params;
        
        const result = await TestimonialService.deleteTestimonial(id);
        
        logger.warn('Testimonial deleted by admin', {
            testimonialId: id,
            deletedBy: req.user.id
        });
        
        ResponseHandler.success(res, result, 'Testimonial deleted successfully');
    });

    /**
     * Get testimonial analytics (admin only)
     * GET /api/testimonials/analytics
     */
    static getTestimonialAnalytics = asyncHandler(async (req, res) => {
        const filters = {
            startDate: req.query.startDate,
            endDate: req.query.endDate
        };
        
        const analytics = await TestimonialService.getTestimonialAnalytics(filters);
        
        ResponseHandler.success(res, analytics, 'Testimonial analytics retrieved');
    });

    /**
     * Bulk approve testimonials (admin only)
     * POST /api/testimonials/bulk-approve
     */
    static bulkApproveTestimonials = asyncHandler(async (req, res) => {
        const { testimonialIds, notes } = req.body;
        const moderatorId = req.user.id;
        
        const results = [];
        let successCount = 0;
        let errorCount = 0;
        
        for (const id of testimonialIds) {
            try {
                const testimonial = await TestimonialService.approveTestimonial(id, moderatorId, notes);
                results.push({ id, success: true, testimonial });
                successCount++;
            } catch (error) {
                results.push({ id, success: false, error: error.message });
                errorCount++;
            }
        }
        
        logger.info('Bulk testimonial approval completed', {
            moderatorId,
            totalProcessed: testimonialIds.length,
            successCount,
            errorCount
        });
        
        ResponseHandler.success(res, {
            results,
            summary: {
                totalProcessed: testimonialIds.length,
                successCount,
                errorCount
            }
        }, 'Bulk approval completed');
    });

    /**
     * Export testimonials to CSV (admin only)
     * GET /api/testimonials/export
     */
    static exportTestimonials = asyncHandler(async (req, res) => {
        const options = {
            isApproved: req.query.isApproved,
            rating: req.query.rating,
            startDate: req.query.startDate,
            endDate: req.query.endDate,
            includePrivate: true,
            limit: 10000 // Large limit for export
        };
        
        const result = await TestimonialService.getTestimonials(options);
        
        // Convert to CSV format
        const csvData = result.testimonials.map(testimonial => ({
            id: testimonial.id,
            name: testimonial.name,
            rating: testimonial.rating,
            review: testimonial.review.replace(/,/g, ';'), // Replace commas to avoid CSV issues
            isApproved: testimonial.isApproved,
            isFeatured: testimonial.isFeatured,
            isVisible: testimonial.isVisible,
            createdAt: testimonial.createdAt,
            approvedAt: testimonial.approvedAt || 'N/A'
        }));
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=testimonials-export.csv');
        
        // Convert to CSV string
        const csvString = [
            Object.keys(csvData[0]).join(','),
            ...csvData.map(row => Object.values(row).map(val => 
                typeof val === 'string' && val.includes(',') ? `"${val}"` : val
            ).join(','))
        ].join('\\n');
        
        logger.info('Testimonials exported', {
            count: csvData.length,
            exportedBy: req.user.id,
            filters: options
        });
        
        res.send(csvString);
    });
}

module.exports = TestimonialController;
"""

# Save controller files
with open('authController.js', 'w') as f:
    f.write(auth_controller)

with open('donationController.js', 'w') as f:
    f.write(donation_controller)

with open('testimonialController.js', 'w') as f:
    f.write(testimonial_controller)

print("✅ Created controller files:")
print("  - src/controllers/authController.js")
print("  - src/controllers/donationController.js") 
print("  - src/controllers/testimonialController.js")