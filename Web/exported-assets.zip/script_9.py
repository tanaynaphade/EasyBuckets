# Create main application files

# app.js
app_js = """const express = require('express');
const morgan = require('morgan');
const config = require('./src/config/environment');
const database = require('./src/config/database');
const routes = require('./src/routes');
const { globalErrorHandler, notFoundHandler } = require('./src/utils/errorHandler');
const logger = require('./src/utils/logger');

// Security middleware
const {
    securityHeaders,
    cors,
    compression,
    requestLogger,
    ipSecurity,
    validateContentType,
    requestSizeLimiter,
    apiVersioning,
    requestTimeout
} = require('./src/middleware/security');

// Create Express app
const app = express();

// Trust proxy (important for rate limiting and IP detection when behind reverse proxy)
app.set('trust proxy', 1);

// Security middleware
app.use(securityHeaders);
app.use(cors);
app.use(compression);
app.use(ipSecurity);
app.use(requestTimeout(30000)); // 30 second timeout
app.use(requestSizeLimiter('10mb'));

// Request logging
if (config.isProduction()) {
    app.use(morgan('combined', { stream: logger.stream }));
} else {
    app.use(morgan('dev'));
}
app.use(requestLogger);

// Body parsing middleware
app.use(express.json({
    limit: '10mb',
    verify: (req, res, buf) => {
        req.rawBody = buf;
    }
}));
app.use(express.urlencoded({ 
    extended: true, 
    limit: '10mb' 
}));

// Content type validation
app.use(validateContentType(['application/json', 'application/x-www-form-urlencoded']));

// API versioning
app.use(apiVersioning);

// Root route
app.get('/', (req, res) => {
    res.json({
        success: true,
        message: 'NBA Analytics Dashboard API',
        version: '1.0.0',
        environment: config.NODE_ENV,
        timestamp: new Date().toISOString(),
        documentation: '/api/docs',
        health: '/api/health'
    });
});

// API routes
app.use('/api', routes);

// Handle 404 errors
app.use(notFoundHandler);

// Global error handler
app.use(globalErrorHandler);

// Database connection
const connectDatabase = async () => {
    try {
        await database.connect();
        logger.info('✅ Database connected successfully');
    } catch (error) {
        logger.error('❌ Database connection failed:', error);
        process.exit(1);
    }
};

// Initialize database connection if not in test environment
if (process.env.NODE_ENV !== 'test') {
    connectDatabase();
}

// Handle process termination gracefully
process.on('SIGTERM', async () => {
    logger.info('SIGTERM received, shutting down gracefully...');
    await database.disconnect();
    process.exit(0);
});

process.on('SIGINT', async () => {
    logger.info('SIGINT received, shutting down gracefully...');
    await database.disconnect();
    process.exit(0);
});

module.exports = app;
"""

# server.js
server_js = """const app = require('./app');
const config = require('./src/config/environment');
const logger = require('./src/utils/logger');
const { gracefulShutdown } = require('./src/utils/errorHandler');

const PORT = config.PORT;

// Start server
const server = app.listen(PORT, () => {
    logger.info(`🚀 NBA Analytics Backend Server running on port ${PORT}`);
    logger.info(`📊 Environment: ${config.NODE_ENV}`);
    logger.info(`🔗 Health Check: http://localhost:${PORT}/api/health`);
    logger.info(`📖 API Docs: http://localhost:${PORT}/api/docs`);
    
    if (config.isDevelopment()) {
        logger.info(`🐛 Development mode enabled`);
        logger.info(`📝 Detailed logging enabled`);
    }
});

// Handle server startup errors
server.on('error', (error) => {
    if (error.code === 'EADDRINUSE') {
        logger.error(`❌ Port ${PORT} is already in use`);
        process.exit(1);
    } else {
        logger.error('❌ Server startup error:', error);
        process.exit(1);
    }
});

// Setup graceful shutdown
gracefulShutdown(server);

// Export server for testing
module.exports = server;
"""

# healthcheck.js (for Docker health check)
healthcheck_js = """const http = require('http');
const config = require('./src/config/environment');

const options = {
    hostname: 'localhost',
    port: config.PORT,
    path: '/api/health',
    method: 'GET',
    timeout: 3000
};

const req = http.request(options, (res) => {
    if (res.statusCode === 200) {
        console.log('Health check passed');
        process.exit(0);
    } else {
        console.log(`Health check failed with status code: ${res.statusCode}`);
        process.exit(1);
    }
});

req.on('error', (error) => {
    console.log(`Health check failed: ${error.message}`);
    process.exit(1);
});

req.on('timeout', () => {
    console.log('Health check timed out');
    req.destroy();
    process.exit(1);
});

req.end();
"""

# README.md
readme_content = """# NBA Analytics Dashboard Backend

A comprehensive backend API for an NBA analytics dashboard built with Node.js, Express.js, and MongoDB. Features secure user authentication, donation management with leaderboards, and testimonial system.

## 🏀 Features

### Core Functionality
- **Transactions & Leaderboard**: Kickstarter-style donation system with real-time leaderboards
- **User Authentication**: Secure JWT-based authentication with refresh tokens
- **Testimonials**: Public testimonial submission and moderation system
- **Security**: Industry-standard security practices with bcrypt, rate limiting, and input validation

### Technical Features
- **MongoDB Integration**: Scalable NoSQL database with Mongoose ODM
- **Docker Support**: Full containerization with Docker Compose
- **Environment Configuration**: Secure environment variable management
- **Rate Limiting**: Comprehensive rate limiting for different endpoints
- **Input Validation**: Robust validation and sanitization
- **Error Handling**: Centralized error handling with detailed logging
- **API Documentation**: Built-in API documentation and health checks

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- Docker & Docker Compose
- MongoDB (if not using Docker)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd nba-analytics-backend
   ```

2. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

3. **Using Docker (Recommended)**
   ```bash
   docker-compose up -d
   ```

4. **Or run locally**
   ```bash
   npm install
   npm run dev
   ```

### Environment Variables

```env
# MongoDB Configuration
MONGODB_URI=mongodb://mongo:27017/nba_analytics
MONGODB_USER=nba_user
MONGODB_PASSWORD=secure_password_123

# JWT Configuration  
JWT_SECRET=your-super-secure-jwt-secret-key-min-32-chars
JWT_EXPIRES_IN=24h

# Server Configuration
PORT=5000
NODE_ENV=development

# Security Configuration
BCRYPT_ROUNDS=12
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

## 📊 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/profile` - Get user profile
- `POST /api/auth/refresh` - Refresh access token

### Donations
- `POST /api/donations` - Submit donation
- `GET /api/donations/leaderboard` - Get leaderboard
- `GET /api/donations/stats` - Get donation statistics
- `GET /api/donations` - Get donations (auth required)

### Testimonials
- `POST /api/testimonials` - Submit testimonial
- `GET /api/testimonials/approved` - Get approved testimonials
- `GET /api/testimonials/featured` - Get featured testimonials
- `GET /api/testimonials/stats/ratings` - Get rating statistics

### System
- `GET /api/health` - Health check
- `GET /api/docs` - API documentation
- `GET /api/status` - System status

## 🏗️ Architecture

```
src/
├── config/          # Configuration files
│   ├── database.js  # MongoDB connection
│   ├── jwt.js       # JWT configuration
│   └── environment.js # Environment variables
├── controllers/     # Request handlers
├── middleware/      # Custom middleware
├── models/          # MongoDB schemas
├── routes/          # API route definitions
├── services/        # Business logic
└── utils/           # Utility functions
```

## 🛡️ Security Features

- **Password Hashing**: bcrypt with configurable rounds
- **JWT Authentication**: Secure token-based authentication
- **Rate Limiting**: Multiple rate limiting strategies
- **Input Validation**: Comprehensive request validation
- **Security Headers**: Helmet.js security headers
- **CORS**: Configurable cross-origin resource sharing
- **Request Sanitization**: XSS protection and input cleaning

## 🐳 Docker Configuration

The application includes a complete Docker setup:

- **Multi-stage build** for optimized production images
- **MongoDB container** with persistent volumes
- **Health checks** for container monitoring
- **Network isolation** for security
- **Environment-based configuration**

## 📝 Development

### Available Scripts
- `npm start` - Start production server
- `npm run dev` - Start development server with nodemon
- `npm test` - Run tests
- `npm run docker:build` - Build Docker image
- `npm run docker:run` - Start with Docker Compose

### Code Structure
- **Controllers**: Handle HTTP requests and responses
- **Services**: Contain business logic and data processing
- **Models**: Define database schemas and methods
- **Middleware**: Handle authentication, validation, and security
- **Utils**: Shared utilities for logging, error handling, and responses

## 🔧 Configuration

### Rate Limiting
- General API: 100 requests per 15 minutes
- Authentication: 5 attempts per 15 minutes
- Donations: 10 submissions per hour
- Testimonials: 2 submissions per hour

### Security Settings
- Password minimum: 8 characters with complexity requirements
- JWT expiry: 24 hours (configurable)
- bcrypt rounds: 12 (configurable)
- Account lockout: 5 failed attempts, 2-hour lock

## 🚀 Deployment

### Production Checklist
- [ ] Set `NODE_ENV=production`
- [ ] Use strong JWT secrets
- [ ] Configure proper MongoDB authentication
- [ ] Set up SSL/TLS termination
- [ ] Configure log rotation
- [ ] Set up monitoring and alerting
- [ ] Review and adjust rate limits
- [ ] Configure backup strategy

### Environment-specific Configuration
The application supports multiple environments with different configurations:
- **Development**: Detailed logging, relaxed security
- **Production**: Optimized performance, strict security
- **Test**: Isolated database, minimal logging

## 📋 API Documentation

Visit `/api/docs` when the server is running for complete API documentation including:
- Available endpoints
- Request/response schemas
- Authentication requirements
- Rate limiting information
- Example requests

## 🔍 Monitoring & Logging

### Health Checks
- **Application**: `/api/health` - Basic application health
- **Database**: `/api/status` - Detailed system status including DB connectivity
- **Docker**: Built-in health check for container monitoring

### Logging
- **Winston**: Structured logging with multiple transports
- **Morgan**: HTTP request logging
- **Error Tracking**: Comprehensive error logging with stack traces
- **Security Events**: Failed login attempts and suspicious activity

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- Check the API documentation at `/api/docs`
- Review the health check at `/api/health`
- Check application logs for debugging information

## 🔄 Updates & Maintenance

Regular maintenance tasks:
- Update dependencies
- Review security configurations
- Monitor performance metrics
- Backup database regularly
- Update documentation
"""

# Save main application files
with open('app.js', 'w') as f:
    f.write(app_js)

with open('server.js', 'w') as f:
    f.write(server_js)

with open('healthcheck.js', 'w') as f:
    f.write(healthcheck_js)

with open('README.md', 'w') as f:
    f.write(readme_content)

print("✅ Created main application files:")
print("  - app.js")
print("  - server.js")
print("  - healthcheck.js")
print("  - README.md")