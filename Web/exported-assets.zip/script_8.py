# Create route files

# src/routes/authRoutes.js
auth_routes = """const express = require('express');
const AuthController = require('../controllers/authController');
const { authenticate, validateRefreshToken } = require('../middleware/auth');
const { 
    validateRegistration, 
    validateLogin, 
    validatePasswordChange,
    sanitizeInput 
} = require('../middleware/validation');
const { 
    authLimiter, 
    registrationLimiter, 
    passwordResetLimiter 
} = require('../middleware/rateLimiter');

const router = express.Router();

// Public routes (no authentication required)
router.post('/register', 
    registrationLimiter,
    sanitizeInput,
    validateRegistration,
    AuthController.register
);

router.post('/login', 
    authLimiter,
    sanitizeInput,
    validateLogin,
    AuthController.login
);

router.post('/refresh',
    authLimiter,
    validateRefreshToken,
    AuthController.refreshToken
);

// Protected routes (authentication required)
router.use(authenticate); // All routes below require authentication

router.post('/logout',
    AuthController.logout
);

router.post('/logout-all',
    AuthController.logoutAll
);

router.get('/profile',
    AuthController.getProfile
);

router.put('/profile',
    sanitizeInput,
    AuthController.updateProfile
);

router.post('/change-password',
    passwordResetLimiter,
    sanitizeInput,
    validatePasswordChange,
    AuthController.changePassword
);

router.delete('/account',
    AuthController.deactivateAccount
);

router.get('/stats',
    AuthController.getUserStats
);

router.get('/verify',
    AuthController.verifyToken
);

router.get('/session',
    AuthController.getSessionInfo
);

module.exports = router;
"""

# src/routes/donationRoutes.js
donation_routes = """const express = require('express');
const DonationController = require('../controllers/donationController');
const { authenticate, authorize } = require('../middleware/auth');
const { 
    validateDonation, 
    validateObjectId, 
    validatePagination,
    sanitizeInput 
} = require('../middleware/validation');
const { 
    donationLimiter, 
    generalLimiter 
} = require('../middleware/rateLimiter');

const router = express.Router();

// Public routes (no authentication required)
router.post('/',
    donationLimiter,
    sanitizeInput,
    validateDonation,
    DonationController.createDonation
);

router.get('/leaderboard',
    generalLimiter,
    DonationController.getLeaderboard
);

router.get('/stats',
    generalLimiter,
    DonationController.getDonationStats
);

// Webhook route for payment processors (no auth, but should validate signature in real app)
router.post('/webhook',
    DonationController.processWebhook
);

// Protected routes (authentication required)
router.get('/',
    authenticate,
    validatePagination,
    DonationController.getDonations
);

router.get('/export',
    authenticate,
    authorize('admin'),
    DonationController.exportDonations
);

router.get('/by-email/:email',
    authenticate,
    authorize('admin', 'moderator'),
    validatePagination,
    DonationController.getDonationsByEmail
);

router.get('/:id',
    authenticate,
    authorize('admin', 'moderator'),
    validateObjectId('id'),
    DonationController.getDonationById
);

// Admin routes
router.patch('/:id/status',
    authenticate,
    authorize('admin'),
    validateObjectId('id'),
    sanitizeInput,
    DonationController.updateDonationStatus
);

router.delete('/:id',
    authenticate,
    authorize('admin'),
    validateObjectId('id'),
    DonationController.deleteDonation
);

module.exports = router;
"""

# src/routes/testimonialRoutes.js
testimonial_routes = """const express = require('express');
const TestimonialController = require('../controllers/testimonialController');
const { authenticate, authorize, optionalAuth } = require('../middleware/auth');
const { 
    validateTestimonial, 
    validateObjectId, 
    validatePagination,
    sanitizeInput 
} = require('../middleware/validation');
const { 
    testimonialLimiter, 
    generalLimiter 
} = require('../middleware/rateLimiter');

const router = express.Router();

// Public routes (no authentication required)
router.post('/',
    testimonialLimiter,
    sanitizeInput,
    validateTestimonial,
    TestimonialController.createTestimonial
);

router.get('/approved',
    generalLimiter,
    TestimonialController.getApprovedTestimonials
);

router.get('/featured',
    generalLimiter,
    TestimonialController.getFeaturedTestimonials
);

router.get('/rating/:rating',
    generalLimiter,
    TestimonialController.getTestimonialsByRating
);

router.get('/stats/ratings',
    generalLimiter,
    TestimonialController.getRatingStats
);

// Routes with optional authentication (different data for authenticated users)
router.get('/',
    optionalAuth,
    validatePagination,
    TestimonialController.getTestimonials
);

router.get('/:id',
    optionalAuth,
    validateObjectId('id'),
    TestimonialController.getTestimonialById
);

// Protected routes (authentication required)
// Moderator routes
router.use(authenticate); // All routes below require authentication

router.get('/pending',
    authorize('admin', 'moderator'),
    TestimonialController.getPendingTestimonials
);

router.patch('/:id/approve',
    authorize('admin', 'moderator'),
    validateObjectId('id'),
    sanitizeInput,
    TestimonialController.approveTestimonial
);

router.patch('/:id/reject',
    authorize('admin', 'moderator'),
    validateObjectId('id'),
    sanitizeInput,
    TestimonialController.rejectTestimonial
);

router.post('/bulk-approve',
    authorize('admin', 'moderator'),
    sanitizeInput,
    TestimonialController.bulkApproveTestimonials
);

// Admin-only routes
router.get('/analytics',
    authorize('admin'),
    TestimonialController.getTestimonialAnalytics
);

router.get('/export',
    authorize('admin'),
    TestimonialController.exportTestimonials
);

router.patch('/:id/feature',
    authorize('admin'),
    validateObjectId('id'),
    sanitizeInput,
    TestimonialController.featureTestimonial
);

router.patch('/:id/visibility',
    authorize('admin'),
    validateObjectId('id'),
    sanitizeInput,
    TestimonialController.toggleVisibility
);

router.delete('/:id',
    authorize('admin'),
    validateObjectId('id'),
    TestimonialController.deleteTestimonial
);

module.exports = router;
"""

# src/routes/index.js
index_routes = """const express = require('express');
const authRoutes = require('./authRoutes');
const donationRoutes = require('./donationRoutes');
const testimonialRoutes = require('./testimonialRoutes');
const { generalLimiter } = require('../middleware/rateLimiter');
const ResponseHandler = require('../utils/responseHandler');
const { NotFoundError } = require('../utils/errorHandler');

const router = express.Router();

// Apply general rate limiting to all API routes
router.use(generalLimiter);

// API health check
router.get('/health', (req, res) => {
    const healthCheck = {
        status: 'OK',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: process.env.NODE_ENV,
        version: '1.0.0',
        services: {
            database: 'connected', // This would check actual DB status in production
            redis: 'not_configured',
            external_apis: 'not_configured'
        }
    };
    
    ResponseHandler.success(res, healthCheck, 'Service is healthy');
});

// API documentation endpoint
router.get('/docs', (req, res) => {
    const apiDocs = {
        name: 'NBA Analytics Dashboard API',
        version: '1.0.0',
        description: 'Backend API for NBA Analytics Dashboard with donations and testimonials',
        endpoints: {
            auth: {
                base: '/api/auth',
                description: 'User authentication and profile management',
                endpoints: [
                    'POST /register - Register new user',
                    'POST /login - User login', 
                    'POST /logout - User logout',
                    'GET /profile - Get user profile',
                    'PUT /profile - Update user profile',
                    'POST /change-password - Change password'
                ]
            },
            donations: {
                base: '/api/donations',
                description: 'Donation management and leaderboard',
                endpoints: [
                    'POST / - Submit donation',
                    'GET / - Get donations (auth required)',
                    'GET /leaderboard - Get donation leaderboard',
                    'GET /stats - Get donation statistics'
                ]
            },
            testimonials: {
                base: '/api/testimonials',
                description: 'User testimonials and reviews',
                endpoints: [
                    'POST / - Submit testimonial',
                    'GET / - Get testimonials',
                    'GET /approved - Get approved testimonials',
                    'GET /featured - Get featured testimonials',
                    'GET /stats/ratings - Get rating statistics'
                ]
            }
        },
        authentication: {
            type: 'JWT Bearer Token',
            header: 'Authorization: Bearer <token>'
        },
        rateLimit: {
            general: '100 requests per 15 minutes',
            auth: '5 requests per 15 minutes',
            donations: '10 requests per hour',
            testimonials: '2 requests per hour'
        }
    };
    
    ResponseHandler.success(res, apiDocs, 'API documentation retrieved');
});

// Route definitions
router.use('/auth', authRoutes);
router.use('/donations', donationRoutes);
router.use('/testimonials', testimonialRoutes);

// API status endpoint with database connectivity check
router.get('/status', async (req, res) => {
    try {
        const database = require('../config/database');
        const dbStatus = database.getConnectionStatus();
        
        const status = {
            api: 'running',
            database: dbStatus.isConnected ? 'connected' : 'disconnected',
            timestamp: new Date().toISOString(),
            version: '1.0.0',
            uptime: `${Math.floor(process.uptime())} seconds`,
            memory: {
                used: Math.round(process.memoryUsage().heapUsed / 1024 / 1024) + ' MB',
                total: Math.round(process.memoryUsage().heapTotal / 1024 / 1024) + ' MB'
            },
            environment: process.env.NODE_ENV
        };
        
        ResponseHandler.success(res, status, 'System status retrieved');
    } catch (error) {
        ResponseHandler.error(res, 'Error retrieving system status', 500);
    }
});

// API metrics endpoint (simple implementation)
router.get('/metrics', (req, res) => {
    const metrics = {
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        cpu: process.cpuUsage(),
        version: process.version,
        platform: process.platform,
        architecture: process.arch
    };
    
    ResponseHandler.success(res, metrics, 'System metrics retrieved');
});

// Catch-all route for undefined endpoints
router.all('*', (req, res, next) => {
    next(new NotFoundError(`Route ${req.originalUrl} not found`));
});

module.exports = router;
"""

# Save route files
with open('authRoutes.js', 'w') as f:
    f.write(auth_routes)

with open('donationRoutes.js', 'w') as f:
    f.write(donation_routes)

with open('testimonialRoutes.js', 'w') as f:
    f.write(testimonial_routes)

with open('index.js', 'w') as f:
    f.write(index_routes)

print("✅ Created route files:")
print("  - src/routes/authRoutes.js")
print("  - src/routes/donationRoutes.js") 
print("  - src/routes/testimonialRoutes.js")
print("  - src/routes/index.js")