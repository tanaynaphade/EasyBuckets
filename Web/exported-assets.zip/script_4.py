# Create middleware files

# src/middleware/auth.js
auth_middleware = """const jwtManager = require('../config/jwt');
const User = require('../models/User');
const { AppError } = require('../utils/errorHandler');
const logger = require('../utils/logger');

/**
 * Authentication middleware
 * Verifies JWT token and attaches user to request
 */
const authenticate = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        
        if (!authHeader) {
            return next(new AppError('Access token is required', 401));
        }

        const token = jwtManager.extractToken(authHeader);
        const decoded = jwtManager.verifyAccessToken(token);
        
        // Check if user still exists
        const user = await User.findById(decoded.id).select('+isActive');
        if (!user) {
            return next(new AppError('User no longer exists', 401));
        }

        // Check if user is active
        if (!user.isActive) {
            return next(new AppError('Account is deactivated', 401));
        }

        // Check if user is locked
        if (user.isLocked) {
            return next(new AppError('Account is temporarily locked', 423));
        }

        // Check if password was changed after token was issued
        const tokenIssuedAt = new Date(decoded.iat * 1000);
        if (user.passwordChangedAt && user.passwordChangedAt > tokenIssuedAt) {
            return next(new AppError('Password recently changed. Please log in again', 401));
        }

        // Attach user to request
        req.user = user;
        next();
    } catch (error) {
        if (error.name === 'JsonWebTokenError') {
            return next(new AppError('Invalid token', 401));
        }
        if (error.name === 'TokenExpiredError') {
            return next(new AppError('Token has expired', 401));
        }
        logger.error('Authentication error:', error);
        return next(new AppError('Authentication failed', 401));
    }
};

/**
 * Optional authentication middleware
 * Attaches user if token is present but doesn't require it
 */
const optionalAuth = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        
        if (!authHeader) {
            req.user = null;
            return next();
        }

        const token = jwtManager.extractToken(authHeader);
        const decoded = jwtManager.verifyAccessToken(token);
        
        const user = await User.findById(decoded.id).select('+isActive');
        if (user && user.isActive && !user.isLocked) {
            req.user = user;
        } else {
            req.user = null;
        }
        
        next();
    } catch (error) {
        // If token is invalid, just set user to null
        req.user = null;
        next();
    }
};

/**
 * Authorization middleware factory
 * Checks if user has required role
 */
const authorize = (...roles) => {
    return (req, res, next) => {
        if (!req.user) {
            return next(new AppError('Authentication required', 401));
        }

        if (!roles.includes(req.user.role)) {
            logger.warn(`Unauthorized access attempt by user ${req.user.email} with role ${req.user.role}`);
            return next(new AppError('Insufficient permissions', 403));
        }

        next();
    };
};

/**
 * Middleware to check if user owns the resource
 * Compares req.user.id with req.params.userId or resource owner
 */
const checkOwnership = (resourcePath = 'userId') => {
    return (req, res, next) => {
        if (!req.user) {
            return next(new AppError('Authentication required', 401));
        }

        const resourceOwnerId = req.params[resourcePath] || req.body[resourcePath];
        
        // Admin can access all resources
        if (req.user.role === 'admin') {
            return next();
        }

        // User can only access their own resources
        if (req.user._id.toString() !== resourceOwnerId) {
            return next(new AppError('Access denied', 403));
        }

        next();
    };
};

/**
 * Middleware to validate refresh token
 */
const validateRefreshToken = async (req, res, next) => {
    try {
        const { refreshToken } = req.body;
        
        if (!refreshToken) {
            return next(new AppError('Refresh token is required', 400));
        }

        const decoded = jwtManager.verifyRefreshToken(refreshToken);
        
        // Find user and check if refresh token exists
        const user = await User.findById(decoded.id).select('+refreshTokens');
        if (!user) {
            return next(new AppError('User no longer exists', 401));
        }

        const storedToken = user.refreshTokens.find(rt => rt.token === refreshToken);
        if (!storedToken) {
            return next(new AppError('Invalid refresh token', 401));
        }

        req.user = user;
        req.refreshToken = refreshToken;
        next();
    } catch (error) {
        if (error.name === 'JsonWebTokenError') {
            return next(new AppError('Invalid refresh token', 401));
        }
        if (error.name === 'TokenExpiredError') {
            return next(new AppError('Refresh token has expired', 401));
        }
        logger.error('Refresh token validation error:', error);
        return next(new AppError('Token validation failed', 401));
    }
};

module.exports = {
    authenticate,
    optionalAuth,
    authorize,
    checkOwnership,
    validateRefreshToken
};
"""

# src/middleware/rateLimiter.js
rate_limiter_middleware = """const rateLimit = require('express-rate-limit');
const config = require('../config/environment');
const logger = require('../utils/logger');

/**
 * Create a custom rate limiter
 */
const createLimiter = (options = {}) => {
    const defaultOptions = {
        windowMs: config.SECURITY.RATE_LIMIT_WINDOW_MS,
        max: config.SECURITY.RATE_LIMIT_MAX_REQUESTS,
        message: {
            error: 'Too many requests from this IP',
            message: 'Please try again later',
            retryAfter: Math.ceil(config.SECURITY.RATE_LIMIT_WINDOW_MS / 1000 / 60) // minutes
        },
        standardHeaders: true,
        legacyHeaders: false,
        keyGenerator: (req) => {
            // Use forwarded IP if behind proxy, otherwise use connection IP
            return req.ip || req.connection.remoteAddress;
        },
        handler: (req, res) => {
            logger.warn(`Rate limit exceeded for IP: ${req.ip}`);
            res.status(429).json({
                success: false,
                error: options.message || 'Too many requests',
                retryAfter: Math.round(req.rateLimit.resetTime / 1000)
            });
        },
        onLimitReached: (req, res, options) => {
            logger.warn(`Rate limit reached for IP: ${req.ip}, endpoint: ${req.originalUrl}`);
        }
    };

    return rateLimit({ ...defaultOptions, ...options });
};

/**
 * General API rate limiter - 100 requests per 15 minutes
 */
const generalLimiter = createLimiter({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100,
    message: {
        error: 'Too many API requests',
        message: 'You have exceeded the rate limit. Please try again later.',
        retryAfter: 15
    }
});

/**
 * Strict rate limiter for authentication endpoints - 5 requests per 15 minutes
 */
const authLimiter = createLimiter({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5,
    message: {
        error: 'Too many authentication attempts',
        message: 'Too many login attempts. Please try again later.',
        retryAfter: 15
    },
    skipSuccessfulRequests: true // Don't count successful requests
});

/**
 * Registration rate limiter - 3 registrations per hour per IP
 */
const registrationLimiter = createLimiter({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 3,
    message: {
        error: 'Too many registration attempts',
        message: 'Maximum registrations per hour exceeded. Please try again later.',
        retryAfter: 60
    }
});

/**
 * Password reset limiter - 3 attempts per hour per IP
 */
const passwordResetLimiter = createLimiter({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 3,
    message: {
        error: 'Too many password reset requests',
        message: 'Too many password reset attempts. Please try again later.',
        retryAfter: 60
    }
});

/**
 * Donation submission limiter - 10 donations per hour per IP
 */
const donationLimiter = createLimiter({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 10,
    message: {
        error: 'Too many donation submissions',
        message: 'Maximum donations per hour exceeded. Please try again later.',
        retryAfter: 60
    }
});

/**
 * Testimonial submission limiter - 2 testimonials per hour per IP
 */
const testimonialLimiter = createLimiter({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 2,
    message: {
        error: 'Too many testimonial submissions',
        message: 'Maximum testimonials per hour exceeded. Please try again later.',
        retryAfter: 60
    }
});

/**
 * Dynamic limiter based on user authentication status
 */
const dynamicLimiter = (authenticatedMax, unauthenticatedMax) => {
    return [
        createLimiter({
            max: unauthenticatedMax,
            skip: (req) => req.user !== undefined, // Skip if authenticated
            keyGenerator: (req) => req.ip
        }),
        createLimiter({
            max: authenticatedMax,
            skip: (req) => req.user === undefined, // Skip if not authenticated
            keyGenerator: (req) => req.user ? req.user._id.toString() : req.ip
        })
    ];
};

/**
 * Create user-specific rate limiter
 */
const createUserLimiter = (maxRequests, windowMs, message) => {
    return createLimiter({
        max: maxRequests,
        windowMs: windowMs,
        keyGenerator: (req) => {
            if (req.user) {
                return `user_${req.user._id.toString()}`;
            }
            return req.ip;
        },
        message: {
            error: 'User rate limit exceeded',
            message: message || 'You have made too many requests. Please slow down.',
            retryAfter: Math.ceil(windowMs / 1000 / 60)
        }
    });
};

module.exports = {
    generalLimiter,
    authLimiter,
    registrationLimiter,
    passwordResetLimiter,
    donationLimiter,
    testimonialLimiter,
    dynamicLimiter,
    createLimiter,
    createUserLimiter
};
"""

# src/middleware/validation.js
validation_middleware = """const { body, param, query, validationResult } = require('express-validator');
const { AppError } = require('../utils/errorHandler');
const User = require('../models/User');
const mongoose = require('mongoose');

/**
 * Handle validation results
 */
const handleValidationErrors = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const errorMessages = errors.array().map(error => ({
            field: error.path || error.param,
            message: error.msg,
            value: error.value
        }));
        
        return next(new AppError('Validation failed', 400, errorMessages));
    }
    next();
};

/**
 * User registration validation
 */
const validateRegistration = [
    body('name')
        .trim()
        .isLength({ min: 2, max: 50 })
        .withMessage('Name must be between 2 and 50 characters')
        .matches(/^[a-zA-Z\\s'-]+$/)
        .withMessage('Name can only contain letters, spaces, hyphens, and apostrophes'),
    
    body('email')
        .isEmail()
        .normalizeEmail()
        .withMessage('Please provide a valid email address')
        .custom(async (email) => {
            const existingUser = await User.findByEmail(email);
            if (existingUser) {
                throw new Error('Email is already registered');
            }
            return true;
        }),
    
    body('password')
        .isLength({ min: 8 })
        .withMessage('Password must be at least 8 characters long')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]/)
        .withMessage('Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character'),
    
    body('confirmPassword')
        .custom((value, { req }) => {
            if (value !== req.body.password) {
                throw new Error('Passwords do not match');
            }
            return true;
        }),
    
    handleValidationErrors
];

/**
 * User login validation
 */
const validateLogin = [
    body('email')
        .isEmail()
        .normalizeEmail()
        .withMessage('Please provide a valid email address'),
    
    body('password')
        .notEmpty()
        .withMessage('Password is required'),
    
    handleValidationErrors
];

/**
 * Donation validation
 */
const validateDonation = [
    body('donorName')
        .trim()
        .isLength({ min: 2, max: 100 })
        .withMessage('Donor name must be between 2 and 100 characters')
        .matches(/^[a-zA-Z\\s'-]+$/)
        .withMessage('Name can only contain letters, spaces, hyphens, and apostrophes'),
    
    body('donorEmail')
        .isEmail()
        .normalizeEmail()
        .withMessage('Please provide a valid email address'),
    
    body('amount')
        .isFloat({ min: 1, max: 10000 })
        .withMessage('Amount must be between $1 and $10,000'),
    
    body('currency')
        .optional()
        .isIn(['USD', 'EUR', 'GBP', 'CAD'])
        .withMessage('Invalid currency'),
    
    body('message')
        .optional()
        .trim()
        .isLength({ max: 500 })
        .withMessage('Message must not exceed 500 characters'),
    
    body('isAnonymous')
        .optional()
        .isBoolean()
        .withMessage('isAnonymous must be a boolean value'),
    
    body('paymentMethod')
        .isIn(['credit_card', 'paypal', 'bank_transfer', 'crypto'])
        .withMessage('Invalid payment method'),
    
    handleValidationErrors
];

/**
 * Testimonial validation
 */
const validateTestimonial = [
    body('name')
        .trim()
        .isLength({ min: 2, max: 100 })
        .withMessage('Name must be between 2 and 100 characters')
        .matches(/^[a-zA-Z\\s'-]+$/)
        .withMessage('Name can only contain letters, spaces, hyphens, and apostrophes'),
    
    body('email')
        .optional()
        .isEmail()
        .normalizeEmail()
        .withMessage('Please provide a valid email address'),
    
    body('rating')
        .isInt({ min: 1, max: 5 })
        .withMessage('Rating must be an integer between 1 and 5'),
    
    body('review')
        .trim()
        .isLength({ min: 10, max: 1000 })
        .withMessage('Review must be between 10 and 1000 characters'),
    
    handleValidationErrors
];

/**
 * MongoDB ObjectId validation
 */
const validateObjectId = (paramName = 'id') => [
    param(paramName)
        .custom((value) => {
            if (!mongoose.Types.ObjectId.isValid(value)) {
                throw new Error('Invalid ID format');
            }
            return true;
        }),
    handleValidationErrors
];

/**
 * Pagination validation
 */
const validatePagination = [
    query('page')
        .optional()
        .isInt({ min: 1 })
        .withMessage('Page must be a positive integer'),
    
    query('limit')
        .optional()
        .isInt({ min: 1, max: 100 })
        .withMessage('Limit must be between 1 and 100'),
    
    query('sort')
        .optional()
        .isIn(['createdAt', '-createdAt', 'updatedAt', '-updatedAt', 'name', '-name'])
        .withMessage('Invalid sort parameter'),
    
    handleValidationErrors
];

/**
 * Password change validation
 */
const validatePasswordChange = [
    body('currentPassword')
        .notEmpty()
        .withMessage('Current password is required'),
    
    body('newPassword')
        .isLength({ min: 8 })
        .withMessage('New password must be at least 8 characters long')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]/)
        .withMessage('New password must contain at least one uppercase letter, one lowercase letter, one number, and one special character'),
    
    body('confirmPassword')
        .custom((value, { req }) => {
            if (value !== req.body.newPassword) {
                throw new Error('Passwords do not match');
            }
            return true;
        }),
    
    handleValidationErrors
];

/**
 * Email validation (for password reset, etc.)
 */
const validateEmail = [
    body('email')
        .isEmail()
        .normalizeEmail()
        .withMessage('Please provide a valid email address'),
    
    handleValidationErrors
];

/**
 * Search validation
 */
const validateSearch = [
    query('q')
        .optional()
        .trim()
        .isLength({ min: 1, max: 100 })
        .withMessage('Search query must be between 1 and 100 characters'),
    
    query('type')
        .optional()
        .isIn(['donations', 'testimonials', 'users'])
        .withMessage('Invalid search type'),
    
    handleValidationErrors
];

/**
 * Custom sanitization middleware
 */
const sanitizeInput = (req, res, next) => {
    // Remove any HTML tags and scripts from string inputs
    const sanitizeString = (str) => {
        if (typeof str !== 'string') return str;
        return str
            .replace(/<script[^>]*>.*?<\\/script>/gi, '')
            .replace(/<[^>]*>/g, '')
            .trim();
    };

    // Recursively sanitize object
    const sanitizeObject = (obj) => {
        for (let key in obj) {
            if (obj.hasOwnProperty(key)) {
                if (typeof obj[key] === 'string') {
                    obj[key] = sanitizeString(obj[key]);
                } else if (typeof obj[key] === 'object' && obj[key] !== null) {
                    sanitizeObject(obj[key]);
                }
            }
        }
    };

    // Sanitize request body, query, and params
    if (req.body) sanitizeObject(req.body);
    if (req.query) sanitizeObject(req.query);
    if (req.params) sanitizeObject(req.params);

    next();
};

module.exports = {
    validateRegistration,
    validateLogin,
    validateDonation,
    validateTestimonial,
    validateObjectId,
    validatePagination,
    validatePasswordChange,
    validateEmail,
    validateSearch,
    sanitizeInput,
    handleValidationErrors
};
"""

# src/middleware/security.js
security_middleware = """const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const config = require('../config/environment');
const logger = require('../utils/logger');

/**
 * Security headers middleware using Helmet
 */
const securityHeaders = helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
            fontSrc: ["'self'", "https://fonts.gstatic.com"],
            scriptSrc: ["'self'"],
            imgSrc: ["'self'", "data:", "https:"],
            connectSrc: ["'self'"],
            frameSrc: ["'none'"],
            objectSrc: ["'none'"],
            baseUri: ["'self'"],
            formAction: ["'self'"]
        },
        reportOnly: !config.isProduction()
    },
    hsts: {
        maxAge: 31536000,
        includeSubDomains: true,
        preload: true
    },
    noSniff: true,
    frameguard: { action: 'deny' },
    xssFilter: true,
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' }
});

/**
 * CORS configuration
 */
const corsOptions = {
    origin: (origin, callback) => {
        // Allow requests with no origin (mobile apps, etc.)
        if (!origin) return callback(null, true);
        
        const allowedOrigins = config.SECURITY.ALLOWED_ORIGINS;
        
        if (config.isDevelopment()) {
            // In development, allow all origins
            return callback(null, true);
        }
        
        if (allowedOrigins.indexOf(origin) !== -1) {
            callback(null, true);
        } else {
            logger.warn(`CORS blocked origin: ${origin}`);
            callback(new Error('Not allowed by CORS'));
        }
    },
    credentials: true,
    optionsSuccessStatus: 200,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: [
        'Origin',
        'X-Requested-With',
        'Content-Type',
        'Accept',
        'Authorization',
        'X-API-Key'
    ],
    exposedHeaders: [
        'X-Total-Count',
        'X-Page-Count',
        'X-Current-Page'
    ]
};

/**
 * Compression middleware
 */
const compressionMiddleware = compression({
    filter: (req, res) => {
        // Don't compress responses if this request asks for an uncompressed response
        if (req.headers['x-no-compression']) {
            return false;
        }
        
        // Use compression for all other responses
        return compression.filter(req, res);
    },
    threshold: 1024, // Only compress responses larger than 1KB
    level: 6 // Compression level (1-9, 6 is default)
});

/**
 * Request logging middleware
 */
const requestLogger = (req, res, next) => {
    const start = Date.now();
    
    // Log request
    logger.info(`📨 ${req.method} ${req.originalUrl}`, {
        ip: req.ip,
        userAgent: req.get('User-Agent'),
        contentType: req.get('Content-Type')
    });
    
    // Log response when finished
    res.on('finish', () => {
        const duration = Date.now() - start;
        const level = res.statusCode >= 400 ? 'error' : 'info';
        
        logger[level](`📤 ${res.statusCode} ${req.method} ${req.originalUrl} - ${duration}ms`, {
            statusCode: res.statusCode,
            duration,
            contentLength: res.get('Content-Length'),
            ip: req.ip
        });
    });
    
    next();
};

/**
 * IP tracking and security
 */
const ipSecurity = (req, res, next) => {
    // Get real IP address (handling proxies)
    const realIp = req.headers['x-forwarded-for'] || 
                   req.headers['x-real-ip'] || 
                   req.connection.remoteAddress ||
                   req.socket.remoteAddress ||
                   (req.connection.socket ? req.connection.socket.remoteAddress : null);
    
    req.clientIp = realIp;
    
    // Add IP to request object for easier access
    if (!req.ip && realIp) {
        req.ip = realIp.split(',')[0].trim(); // Take first IP if multiple
    }
    
    // Log suspicious activity
    if (req.headers['x-forwarded-for'] && req.headers['x-forwarded-for'].split(',').length > 3) {
        logger.warn('Suspicious request with multiple forwarded IPs:', {
            ip: req.ip,
            forwardedFor: req.headers['x-forwarded-for'],
            userAgent: req.get('User-Agent')
        });
    }
    
    next();
};

/**
 * Content type validation
 */
const validateContentType = (allowedTypes = ['application/json']) => {
    return (req, res, next) => {
        if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
            const contentType = req.get('Content-Type');
            
            if (!contentType || !allowedTypes.some(type => contentType.includes(type))) {
                return res.status(415).json({
                    success: false,
                    error: 'Unsupported Media Type',
                    message: `Content-Type must be one of: ${allowedTypes.join(', ')}`
                });
            }
        }
        next();
    };
};

/**
 * Request size limiter
 */
const requestSizeLimiter = (maxSize = '10mb') => {
    return (req, res, next) => {
        const contentLength = parseInt(req.headers['content-length']);
        const maxBytes = parseSize(maxSize);
        
        if (contentLength && contentLength > maxBytes) {
            return res.status(413).json({
                success: false,
                error: 'Request Too Large',
                message: `Request size exceeds ${maxSize} limit`
            });
        }
        
        next();
    };
};

/**
 * Helper function to parse size strings
 */
const parseSize = (size) => {
    const units = {
        'b': 1,
        'kb': 1024,
        'mb': 1024 * 1024,
        'gb': 1024 * 1024 * 1024
    };
    
    const match = size.toLowerCase().match(/^(\\d+(?:\\.\\d+)?)\\s*(b|kb|mb|gb)?$/);
    if (!match) return 0;
    
    const value = parseFloat(match[1]);
    const unit = match[2] || 'b';
    
    return value * units[unit];
};

/**
 * API versioning middleware
 */
const apiVersioning = (req, res, next) => {
    const version = req.headers['api-version'] || req.query.v || '1.0';
    req.apiVersion = version;
    
    // Set version in response header
    res.set('API-Version', version);
    
    next();
};

/**
 * Request timeout middleware
 */
const requestTimeout = (timeout = 30000) => {
    return (req, res, next) => {
        req.setTimeout(timeout, () => {
            res.status(408).json({
                success: false,
                error: 'Request Timeout',
                message: 'Request took too long to process'
            });
        });
        next();
    };
};

module.exports = {
    securityHeaders,
    cors: cors(corsOptions),
    compression: compressionMiddleware,
    requestLogger,
    ipSecurity,
    validateContentType,
    requestSizeLimiter,
    apiVersioning,
    requestTimeout
};
"""

# Save middleware files
with open('auth.js', 'w') as f:
    f.write(auth_middleware)

with open('rateLimiter.js', 'w') as f:
    f.write(rate_limiter_middleware)

with open('validation.js', 'w') as f:
    f.write(validation_middleware)

with open('security.js', 'w') as f:
    f.write(security_middleware)

print("✅ Created middleware files:")
print("  - src/middleware/auth.js")
print("  - src/middleware/rateLimiter.js") 
print("  - src/middleware/validation.js")
print("  - src/middleware/security.js")