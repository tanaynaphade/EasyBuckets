# Create utility files

# src/utils/logger.js
logger_util = """const winston = require('winston');
const path = require('path');
const config = require('../config/environment');

// Define log levels
const logLevels = {
    error: 0,
    warn: 1,
    info: 2,
    http: 3,
    debug: 4
};

// Define log colors
const logColors = {
    error: 'red',
    warn: 'yellow',
    info: 'green',
    http: 'magenta',
    debug: 'blue'
};

winston.addColors(logColors);

// Create logger
const logger = winston.createLogger({
    level: config.LOGGING.LEVEL,
    levels: logLevels,
    format: winston.format.combine(
        winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        winston.format.errors({ stack: true }),
        winston.format.json()
    ),
    defaultMeta: {
        service: 'nba-analytics-backend',
        version: '1.0.0',
        environment: config.NODE_ENV
    },
    transports: [
        // Error logs
        new winston.transports.File({
            filename: path.join(config.LOGGING.FILE_PATH, 'error.log'),
            level: 'error',
            maxsize: 5242880, // 5MB
            maxFiles: 10,
            format: winston.format.combine(
                winston.format.timestamp(),
                winston.format.json()
            )
        }),
        
        // Combined logs
        new winston.transports.File({
            filename: path.join(config.LOGGING.FILE_PATH, 'combined.log'),
            maxsize: 5242880, // 5MB
            maxFiles: 10,
            format: winston.format.combine(
                winston.format.timestamp(),
                winston.format.json()
            )
        })
    ],
    
    // Handle uncaught exceptions
    exceptionHandlers: [
        new winston.transports.File({
            filename: path.join(config.LOGGING.FILE_PATH, 'exceptions.log')
        })
    ],
    
    // Handle unhandled promise rejections
    rejectionHandlers: [
        new winston.transports.File({
            filename: path.join(config.LOGGING.FILE_PATH, 'rejections.log')
        })
    ]
});

// Add console transport for non-production environments
if (!config.isProduction()) {
    logger.add(new winston.transports.Console({
        format: winston.format.combine(
            winston.format.colorize({ all: true }),
            winston.format.simple(),
            winston.format.printf(({ level, message, timestamp, ...meta }) => {
                let logMessage = `${timestamp} [${level}]: ${message}`;
                
                // Add metadata if present
                if (Object.keys(meta).length > 0) {
                    logMessage += `\\n${JSON.stringify(meta, null, 2)}`;
                }
                
                return logMessage;
            })
        )
    }));
}

// Create a stream for Morgan HTTP logging
logger.stream = {
    write: (message) => {
        logger.http(message.trim());
    }
};

// Helper methods for structured logging
logger.logError = (error, context = {}) => {
    logger.error(error.message || error, {
        stack: error.stack,
        ...context
    });
};

logger.logUserAction = (userId, action, details = {}) => {
    logger.info(`User action: ${action}`, {
        userId,
        action,
        ...details
    });
};

logger.logSecurityEvent = (event, details = {}) => {
    logger.warn(`Security event: ${event}`, {
        event,
        timestamp: new Date().toISOString(),
        ...details
    });
};

logger.logDatabaseEvent = (operation, collection, details = {}) => {
    logger.info(`Database ${operation} on ${collection}`, {
        operation,
        collection,
        ...details
    });
};

logger.logApiRequest = (req, responseTime, statusCode) => {
    logger.http(`${req.method} ${req.originalUrl}`, {
        method: req.method,
        url: req.originalUrl,
        ip: req.ip,
        userAgent: req.get('User-Agent'),
        responseTime,
        statusCode,
        userId: req.user?.id
    });
};

module.exports = logger;
"""

# src/utils/responseHandler.js
response_handler_util = """/**
 * Standardized response handler utility
 * Provides consistent response format across the API
 */

class ResponseHandler {
    /**
     * Send success response
     * @param {Object} res - Express response object
     * @param {*} data - Response data
     * @param {String} message - Success message
     * @param {Number} statusCode - HTTP status code
     * @param {Object} meta - Additional metadata
     */
    static success(res, data = null, message = 'Success', statusCode = 200, meta = {}) {
        const response = {
            success: true,
            message,
            data,
            timestamp: new Date().toISOString(),
            ...meta
        };

        // Remove null or undefined data
        if (data === null || data === undefined) {
            delete response.data;
        }

        return res.status(statusCode).json(response);
    }

    /**
     * Send error response
     * @param {Object} res - Express response object
     * @param {String} message - Error message
     * @param {Number} statusCode - HTTP status code
     * @param {Array} errors - Validation errors array
     * @param {Object} meta - Additional metadata
     */
    static error(res, message = 'An error occurred', statusCode = 500, errors = [], meta = {}) {
        const response = {
            success: false,
            message,
            timestamp: new Date().toISOString(),
            ...meta
        };

        // Add errors if provided
        if (errors && errors.length > 0) {
            response.errors = errors;
        }

        // Add error code for easier client handling
        response.errorCode = this.getErrorCode(statusCode);

        return res.status(statusCode).json(response);
    }

    /**
     * Send paginated response
     * @param {Object} res - Express response object
     * @param {Array} data - Array of items
     * @param {Object} pagination - Pagination info
     * @param {String} message - Success message
     */
    static paginated(res, data, pagination, message = 'Data retrieved successfully') {
        const response = {
            success: true,
            message,
            data,
            pagination: {
                page: pagination.page || 1,
                limit: pagination.limit || 10,
                total: pagination.total || data.length,
                totalPages: Math.ceil((pagination.total || data.length) / (pagination.limit || 10)),
                hasNext: pagination.hasNext || false,
                hasPrev: pagination.hasPrev || false
            },
            timestamp: new Date().toISOString()
        };

        // Set pagination headers
        res.set({
            'X-Total-Count': pagination.total || data.length,
            'X-Page-Count': response.pagination.totalPages,
            'X-Current-Page': pagination.page || 1
        });

        return res.status(200).json(response);
    }

    /**
     * Send created resource response
     * @param {Object} res - Express response object
     * @param {*} data - Created resource data
     * @param {String} message - Success message
     */
    static created(res, data, message = 'Resource created successfully') {
        return this.success(res, data, message, 201);
    }

    /**
     * Send no content response
     * @param {Object} res - Express response object
     */
    static noContent(res) {
        return res.status(204).send();
    }

    /**
     * Send not found response
     * @param {Object} res - Express response object
     * @param {String} message - Error message
     */
    static notFound(res, message = 'Resource not found') {
        return this.error(res, message, 404);
    }

    /**
     * Send unauthorized response
     * @param {Object} res - Express response object
     * @param {String} message - Error message
     */
    static unauthorized(res, message = 'Unauthorized access') {
        return this.error(res, message, 401);
    }

    /**
     * Send forbidden response
     * @param {Object} res - Express response object
     * @param {String} message - Error message
     */
    static forbidden(res, message = 'Access forbidden') {
        return this.error(res, message, 403);
    }

    /**
     * Send validation error response
     * @param {Object} res - Express response object
     * @param {Array} errors - Validation errors
     * @param {String} message - Error message
     */
    static validationError(res, errors, message = 'Validation failed') {
        return this.error(res, message, 400, errors);
    }

    /**
     * Send internal server error response
     * @param {Object} res - Express response object
     * @param {String} message - Error message
     */
    static internalError(res, message = 'Internal server error') {
        return this.error(res, message, 500);
    }

    /**
     * Send too many requests response
     * @param {Object} res - Express response object
     * @param {String} message - Error message
     * @param {Number} retryAfter - Retry after seconds
     */
    static tooManyRequests(res, message = 'Too many requests', retryAfter = null) {
        const meta = retryAfter ? { retryAfter } : {};
        
        if (retryAfter) {
            res.set('Retry-After', retryAfter);
        }

        return this.error(res, message, 429, [], meta);
    }

    /**
     * Get error code based on status code
     * @param {Number} statusCode - HTTP status code
     * @returns {String} Error code
     */
    static getErrorCode(statusCode) {
        const errorCodes = {
            400: 'BAD_REQUEST',
            401: 'UNAUTHORIZED',
            403: 'FORBIDDEN',
            404: 'NOT_FOUND',
            405: 'METHOD_NOT_ALLOWED',
            409: 'CONFLICT',
            422: 'UNPROCESSABLE_ENTITY',
            429: 'TOO_MANY_REQUESTS',
            500: 'INTERNAL_SERVER_ERROR',
            502: 'BAD_GATEWAY',
            503: 'SERVICE_UNAVAILABLE'
        };

        return errorCodes[statusCode] || 'UNKNOWN_ERROR';
    }

    /**
     * Create standardized API response metadata
     * @param {Object} req - Express request object
     * @param {Object} additionalMeta - Additional metadata
     * @returns {Object} Metadata object
     */
    static createMeta(req, additionalMeta = {}) {
        return {
            requestId: req.id,
            apiVersion: req.apiVersion,
            path: req.originalUrl,
            method: req.method,
            ...additionalMeta
        };
    }

    /**
     * Format data with links (HATEOAS style)
     * @param {*} data - Response data
     * @param {Array} links - Array of link objects
     * @returns {Object} Formatted data with links
     */
    static withLinks(data, links = []) {
        return {
            ...data,
            _links: links.reduce((acc, link) => {
                acc[link.rel] = {
                    href: link.href,
                    method: link.method || 'GET'
                };
                return acc;
            }, {})
        };
    }
}

module.exports = ResponseHandler;
"""

# src/utils/errorHandler.js
error_handler_util = """const logger = require('./logger');
const ResponseHandler = require('./responseHandler');

/**
 * Custom error class for application errors
 */
class AppError extends Error {
    constructor(message, statusCode = 500, errors = []) {
        super(message);
        
        this.statusCode = statusCode;
        this.status = `${statusCode}`.startsWith('4') ? 'fail' : 'error';
        this.isOperational = true;
        this.errors = errors;
        
        Error.captureStackTrace(this, this.constructor);
    }
}

/**
 * Validation error class
 */
class ValidationError extends AppError {
    constructor(message, errors = []) {
        super(message, 400, errors);
        this.name = 'ValidationError';
    }
}

/**
 * Authentication error class
 */
class AuthError extends AppError {
    constructor(message = 'Authentication failed') {
        super(message, 401);
        this.name = 'AuthError';
    }
}

/**
 * Authorization error class
 */
class AuthorizationError extends AppError {
    constructor(message = 'Access forbidden') {
        super(message, 403);
        this.name = 'AuthorizationError';
    }
}

/**
 * Not found error class
 */
class NotFoundError extends AppError {
    constructor(resource = 'Resource') {
        super(`${resource} not found`, 404);
        this.name = 'NotFoundError';
    }
}

/**
 * Conflict error class
 */
class ConflictError extends AppError {
    constructor(message = 'Resource conflict') {
        super(message, 409);
        this.name = 'ConflictError';
    }
}

/**
 * Handle cast errors (invalid MongoDB ObjectId)
 */
const handleCastErrorDB = (err) => {
    const message = `Invalid ${err.path}: ${err.value}`;
    return new AppError(message, 400);
};

/**
 * Handle duplicate field errors (MongoDB duplicate key)
 */
const handleDuplicateFieldsDB = (err) => {
    const field = Object.keys(err.keyValue)[0];
    const value = err.keyValue[field];
    const message = `${field} '${value}' already exists`;
    
    return new ConflictError(message);
};

/**
 * Handle validation errors (Mongoose validation)
 */
const handleValidationErrorDB = (err) => {
    const errors = Object.values(err.errors).map(error => ({
        field: error.path,
        message: error.message,
        value: error.value
    }));
    
    return new ValidationError('Invalid input data', errors);
};

/**
 * Handle JWT errors
 */
const handleJWTError = () => {
    return new AuthError('Invalid token. Please log in again');
};

/**
 * Handle JWT expired errors
 */
const handleJWTExpiredError = () => {
    return new AuthError('Token has expired. Please log in again');
};

/**
 * Send error response in development
 */
const sendErrorDev = (err, res) => {
    const response = {
        success: false,
        error: {
            name: err.name,
            message: err.message,
            statusCode: err.statusCode,
            stack: err.stack,
            ...(err.errors && err.errors.length > 0 && { errors: err.errors })
        },
        timestamp: new Date().toISOString()
    };
    
    return res.status(err.statusCode || 500).json(response);
};

/**
 * Send error response in production
 */
const sendErrorProd = (err, res) => {
    // Operational, trusted error: send message to client
    if (err.isOperational) {
        return ResponseHandler.error(
            res, 
            err.message, 
            err.statusCode,
            err.errors
        );
    }
    
    // Programming or other unknown error: don't leak error details
    logger.error('Unexpected error:', {
        name: err.name,
        message: err.message,
        stack: err.stack
    });
    
    return ResponseHandler.internalError(res, 'Something went wrong');
};

/**
 * Global error handling middleware
 */
const globalErrorHandler = (err, req, res, next) => {
    err.statusCode = err.statusCode || 500;
    err.status = err.status || 'error';
    
    // Log error details
    logger.error(`Error ${err.statusCode}: ${err.message}`, {
        error: err.name,
        statusCode: err.statusCode,
        url: req.originalUrl,
        method: req.method,
        ip: req.ip,
        userAgent: req.get('User-Agent'),
        userId: req.user?.id,
        stack: err.stack
    });
    
    if (process.env.NODE_ENV === 'development') {
        sendErrorDev(err, res);
    } else {
        let error = { ...err };
        error.message = err.message;
        
        // Handle specific error types
        if (error.name === 'CastError') {
            error = handleCastErrorDB(error);
        }
        if (error.code === 11000) {
            error = handleDuplicateFieldsDB(error);
        }
        if (error.name === 'ValidationError') {
            error = handleValidationErrorDB(error);
        }
        if (error.name === 'JsonWebTokenError') {
            error = handleJWTError();
        }
        if (error.name === 'TokenExpiredError') {
            error = handleJWTExpiredError();
        }
        
        sendErrorProd(error, res);
    }
};

/**
 * Handle 404 errors for undefined routes
 */
const notFoundHandler = (req, res, next) => {
    const message = `Route ${req.originalUrl} not found`;
    next(new NotFoundError(message));
};

/**
 * Async error wrapper
 * Catches errors from async functions and passes them to error handler
 */
const asyncHandler = (fn) => {
    return (req, res, next) => {
        Promise.resolve(fn(req, res, next)).catch(next);
    };
};

/**
 * Handle unhandled promise rejections
 */
process.on('unhandledRejection', (err, promise) => {
    logger.error('Unhandled Promise Rejection:', {
        error: err.message,
        stack: err.stack,
        promise
    });
    
    // Close server gracefully
    process.exit(1);
});

/**
 * Handle uncaught exceptions
 */
process.on('uncaughtException', (err) => {
    logger.error('Uncaught Exception:', {
        error: err.message,
        stack: err.stack
    });
    
    process.exit(1);
});

/**
 * Graceful shutdown handler
 */
const gracefulShutdown = (server) => {
    const signals = ['SIGTERM', 'SIGINT'];
    
    signals.forEach(signal => {
        process.on(signal, () => {
            logger.info(`Received ${signal}, starting graceful shutdown...`);
            
            server.close(() => {
                logger.info('Process terminated gracefully');
                process.exit(0);
            });
            
            // Force close after 30 seconds
            setTimeout(() => {
                logger.error('Could not close connections in time, forcefully shutting down');
                process.exit(1);
            }, 30000);
        });
    });
};

module.exports = {
    AppError,
    ValidationError,
    AuthError,
    AuthorizationError,
    NotFoundError,
    ConflictError,
    globalErrorHandler,
    notFoundHandler,
    asyncHandler,
    gracefulShutdown
};
"""

# Save utility files
with open('logger.js', 'w') as f:
    f.write(logger_util)

with open('responseHandler.js', 'w') as f:
    f.write(response_handler_util)

with open('errorHandler.js', 'w') as f:
    f.write(error_handler_util)

print("✅ Created utility files:")
print("  - src/utils/logger.js")
print("  - src/utils/responseHandler.js") 
print("  - src/utils/errorHandler.js")