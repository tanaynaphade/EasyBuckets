const mongoose = require('mongoose');
const config = require('./environment');
const logger = require('../utils/logger');

class Database {
    constructor() {
        this.isConnected = false;
        this.connection = null;
    }

    async connect() {
        try {
            if (this.isConnected) {
                logger.warn('Database already connected');
                return this.connection;
            }

            const options = {
                ...config.MONGODB.OPTIONS,
                // Add authentication if credentials are provided
                ...(config.MONGODB.USER && config.MONGODB.PASSWORD && {
                    auth: {
                        username: config.MONGODB.USER,
                        password: config.MONGODB.PASSWORD
                    },
                    authSource: 'admin'
                })
            };

            this.connection = await mongoose.connect(config.MONGODB.URI, options);
            this.isConnected = true;

            logger.info('✅ MongoDB connected successfully');

            // Handle connection events
            this.setupEventListeners();

            return this.connection;
        } catch (error) {
            logger.error('❌ MongoDB connection error:', error);
            throw error;
        }
    }

    setupEventListeners() {
        mongoose.connection.on('connected', () => {
            logger.info('📡 Mongoose connected to MongoDB');
        });

        mongoose.connection.on('error', (err) => {
            logger.error('🚨 Mongoose connection error:', err);
        });

        mongoose.connection.on('disconnected', () => {
            logger.warn('⚠️  Mongoose disconnected from MongoDB');
            this.isConnected = false;
        });

        // Handle application termination
        process.on('SIGINT', async () => {
            await this.disconnect();
            process.exit(0);
        });
    }

    async disconnect() {
        try {
            if (this.isConnected) {
                await mongoose.connection.close();
                this.isConnected = false;
                logger.info('🔌 MongoDB connection closed');
            }
        } catch (error) {
            logger.error('❌ Error closing MongoDB connection:', error);
            throw error;
        }
    }

    getConnectionStatus() {
        return {
            isConnected: this.isConnected,
            readyState: mongoose.connection.readyState,
            host: mongoose.connection.host,
            port: mongoose.connection.port,
            name: mongoose.connection.name
        };
    }
}

module.exports = new Database();
